# 《西游记》原著全本典藏（百回可编辑善本电子书）

基于权威善本汇校整理（源自 https://xiyouji.5000yan.com/ ），一字不漏收录明代吴承恩著《西游记》全一百回、三千五百余条生僻字词通典注释、西天取经十万八千里路线考释、九九八十一难全表及明清批评本提要。

---

## 🚀 Netlify 快速部署指南 (Netlify.ai 规范)

本项目已完全适配 **Netlify** 平台（包含静态站点托管、SPA 路由重写与 Serverless 函数）：

### 1. 自动化部署配置 (`netlify.toml`)
项目根目录已配备完整的 `netlify.toml`：
* **Build Command**: `npm run build`
* **Publish Directory**: `dist`
* **Functions Directory**: `netlify/functions`
* **API 代理**: 自动将 `/api/*` 路由至 `/.netlify/functions/api/:splat`
* **SPA 路由重写**: `/*` 自动重定向至 `/index.html`

### 2. 环境变量配置
在 Netlify 控制台（**Site configuration > Environment variables**）中添加：
| 变量名 | 说明 | 必需 |
| :--- | :--- | :--- |
| `VITE_GEMINI_API_KEY` | Google Gemini API 密钥（驱动 AI 研读学士古典评点） | 推荐 |
| `GEMINI_API_KEY` | 兼容旧版密钥配置 | 可选 |

### 3. Netlify CLI 本地与命令行部署
```bash
# 安装 Netlify CLI
npm install -g netlify-cli

# 登录 Netlify
netlify login

# 一键构建并发布到生产环境
npm run build
netlify deploy --prod --dir=dist --functions=netlify/functions
```

---

## 📖 核心功能特性

1. **一字不漏百回善本**：
   - 818,564 汉字、4,182 个自然段、100% 结构化排版。
   - 诗词、词赋、赞曰独立雕版框展示。

2. **3,561 条字词通典注释**：
   - 包含难字读音注音、词源考释与通典释义。
   - 正文点触唤起古风通典卡片，支持每回生僻词全览索引。

3. **古代中国古籍排版美学**：
   - 文武双边栏（Double Ruling Border）、回纹四角（Greek-Key）。
   - 黑鱼尾版心标记、朱砂印鉴（吴承恩印、李卓吾评、西游释厄）。
   - 四种古雅宣纸底色：熟宣纸、墨砚沉香、竹青素雅、极简素白。

4. **可编辑 PDF 与多源导出**：
   - 生成矢量文本流 PDF（在 Adobe Acrobat、Foxit 或 Word 中可直接二次编辑文本与版式）。
   - 一键下载可编辑 Word 格式 (`.doc`) 及 Markdown (`.md`) 全本。
   - 预留读者批语与读书札记可编辑表单图层。

5. **AI 研读学士 (Gemini Flash)**：
   - 原著段落深度文学赏析、禅宗机锋、内丹心法（心猿意马）考释。
   - 明代嘉靖万历世态讽喻与李卓吾童心说批点评析。

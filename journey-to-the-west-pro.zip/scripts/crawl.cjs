const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const homepageHtml = fs.readFileSync(path.join(__dirname, '../homepage.html'), 'utf-8');
const re = /href=["\x27](?:https:\/\/xiyouji\.5000yan\.com)?\/(\d+)\.html["\x27][^>]*>([\s\S]*?)<\/a>/g;
let match;
const chapters = [];
const seen = new Set();
while ((match = re.exec(homepageHtml)) !== null) {
  const id = match[1];
  const rawTitle = match[2].replace(/<[^>]+>/g, '').trim();
  if (!seen.has(id) && rawTitle.includes('第')) {
    seen.add(id);
    chapters.push({
      chapterIndex: chapters.length + 1,
      id,
      url: `https://xiyouji.5000yan.com/${id}.html`,
      title: rawTitle
    });
  }
}

console.log(`Parsed ${chapters.length} chapters.`);

const outDir = path.join(__dirname, '../src/data/chapters');
fs.mkdirSync(outDir, { recursive: true });

function cleanChapterHtml(rawHtml, meta) {
  const articleMatch = rawHtml.match(/<article class="reading-content[^"]*">([\s\S]*?)<\/article>/i);
  if (!articleMatch) return null;
  let rawContent = articleMatch[1];
  
  // Extract inlink dictionary if present
  let pinyinMap = {};
  const scriptMatch = rawContent.match(/<script[\s\S]*?var\s+inlink_dict\s*=\s*(\{[\s\S]*?\});?<\/script>/i);
  if (scriptMatch) {
    try {
      pinyinMap = JSON.parse(scriptMatch[1]);
    } catch(e) {}
  }

  rawContent = rawContent.replace(/<script[\s\S]*?<\/script>/gi, '');

  const pRegex = /<p[^>]*>([\s\S]*?)<\/p>/gi;
  let pMatch;
  const paragraphs = [];
  while ((pMatch = pRegex.exec(rawContent)) !== null) {
    let text = pMatch[1];
    text = text.replace(/<span[^>]*class=["\x27]inlink-word["\x27][^>]*>(.*?)<\/span>/gi, '$1');
    text = text.replace(/<[^>]+>/g, '').trim();
    if (text) {
      paragraphs.push(text);
    }
  }

  const charCount = paragraphs.reduce((sum, p) => sum + p.replace(/\s+/g, '').length, 0);

  // Classify paragraphs (verse / poem vs prose narrative)
  const structuredParagraphs = paragraphs.map((p, idx) => {
    const isPoemIntro = /^(诗曰|赞曰|词曰|正是|话表|偈曰|判曰|后人有诗赞曰|有诗为证)[：:]?$/.test(p);
    const isPoemLine = (p.length < 40 && /[,，。！]$/.test(p) && !p.startsWith('“') && !p.startsWith('却说') && !p.startsWith('你看') && !p.startsWith('只见'));
    return {
      index: idx + 1,
      text: p,
      isPoemIntro,
      isPoem: isPoemIntro || isPoemLine
    };
  });

  return {
    chapterIndex: meta.chapterIndex,
    id: meta.id,
    title: meta.title,
    url: meta.url,
    charCount,
    paragraphCount: paragraphs.length,
    paragraphs,
    structuredParagraphs,
    pinyinMap
  };
}

async function run() {
  const manifest = [];
  const total = chapters.length;
  const results = new Array(total);
  const concurrency = 8;
  let currentIndex = 0;

  async function worker() {
    while (currentIndex < total) {
      const idx = currentIndex++;
      const ch = chapters[idx];
      const targetFile = path.join(outDir, `chapter_${String(ch.chapterIndex).padStart(3, '0')}.json`);

      let chData;
      if (fs.existsSync(targetFile)) {
        try {
          chData = JSON.parse(fs.readFileSync(targetFile, 'utf-8'));
        } catch(e) {}
      }

      if (!chData) {
        try {
          const raw = execSync(`curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" "${ch.url}"`, { timeout: 20000 }).toString();
          chData = cleanChapterHtml(raw, ch);
          if (chData) {
            fs.writeFileSync(targetFile, JSON.stringify(chData), 'utf-8');
            console.log(`[${ch.chapterIndex}/${total}] Downloaded: ${ch.title} (${chData.charCount} chars)`);
          }
        } catch (err) {
          console.error(`Error downloading chapter ${ch.chapterIndex}:`, err.message);
        }
      }

      if (chData) {
        results[idx] = {
          chapterIndex: ch.chapterIndex,
          id: ch.id,
          title: ch.title,
          charCount: chData.charCount,
          paragraphCount: chData.paragraphCount,
          preview: chData.paragraphs.slice(0, 3).join(' ')
        };
      }
    }
  }

  const workers = Array.from({ length: concurrency }, () => worker());
  await Promise.all(workers);

  const cleanManifest = results.filter(Boolean);
  cleanManifest.sort((a, b) => a.chapterIndex - b.chapterIndex);

  fs.writeFileSync(path.join(__dirname, '../src/data/manifest.json'), JSON.stringify(cleanManifest, null, 2), 'utf-8');
  console.log(`Finished processing all chapters. Manifest written with ${cleanManifest.length} items.`);
}

run();

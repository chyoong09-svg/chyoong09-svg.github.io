const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const chaptersDir = path.join(__dirname, '../src/data/chapters');
const manifestPath = path.join(__dirname, '../src/data/manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));

async function enrichAll() {
  console.log(`Starting to fetch annotations for ${manifest.length} chapters...`);
  const concurrency = 6;
  let idx = 0;
  let totalNotesCount = 0;

  async function worker(workerId) {
    while (idx < manifest.length) {
      const currentIdx = idx++;
      const item = manifest[currentIdx];
      const targetFile = path.join(chaptersDir, `chapter_${String(item.chapterIndex).padStart(3, '0')}.json`);
      
      if (!fs.existsSync(targetFile)) continue;
      const chapterData = JSON.parse(fs.readFileSync(targetFile, 'utf-8'));

      // Fetch chapter page if notes not yet populated or empty
      if (!chapterData.annotations || Object.keys(chapterData.annotations).length === 0) {
        try {
          const raw = execSync(`curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" "${item.url || 'https://xiyouji.5000yan.com/' + item.id + '.html'}"`, { timeout: 15000 }).toString();
          const match = raw.match(/<script type="application\/json" id="article-notes">([\s\S]*?)<\/script>/i);
          let annotations = {};
          if (match) {
            try {
              annotations = JSON.parse(match[1]);
            } catch (e) {}
          }
          chapterData.annotations = annotations;
          chapterData.annotationCount = Object.keys(annotations).length;
          totalNotesCount += chapterData.annotationCount;

          fs.writeFileSync(targetFile, JSON.stringify(chapterData, null, 2), 'utf-8');
          console.log(`[Worker ${workerId}] Ch ${item.chapterIndex}: Added ${chapterData.annotationCount} annotations.`);
        } catch (err) {
          console.error(`Error on chapter ${item.chapterIndex}:`, err.message);
        }
      } else {
        totalNotesCount += Object.keys(chapterData.annotations).length;
      }
    }
  }

  const workers = Array.from({ length: concurrency }, (_, i) => worker(i + 1));
  await Promise.all(workers);
  console.log(`Finished! Total annotations across all chapters: ${totalNotesCount}`);
}

enrichAll();

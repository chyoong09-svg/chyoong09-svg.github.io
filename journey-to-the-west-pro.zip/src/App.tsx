import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ReaderView } from './components/ReaderView';
import { PdfExportModal } from './components/PdfExportModal';
import { EmailModal } from './components/EmailModal';
import { OcrVerificationModal } from './components/OcrVerificationModal';
import { SearchModal } from './components/SearchModal';
import { PrintDocument } from './components/PrintDocument';
import { SupplementaryModal } from './components/SupplementaryModal';
import { AiScholarModal } from './components/AiScholarModal';
import { 
  ChapterSummary, 
  ChapterDetail, 
  ReadingSettings, 
  BookmarkItem 
} from './types';

const DEFAULT_SETTINGS: ReadingSettings = {
  fontSize: 18,
  lineHeight: 1.85,
  theme: 'xuan-paper',
  fontFamily: 'song',
  direction: 'horizontal',
  showAnnotations: true,
  showPinyin: false,
  autoScroll: false
};

export default function App() {
  // Application Data States
  const [chaptersManifest, setChaptersManifest] = useState<ChapterSummary[]>([]);
  const [currentChapterIndex, setCurrentChapterIndex] = useState<number>(1);
  const [currentChapter, setCurrentChapter] = useState<ChapterDetail | null>(null);
  const [loadingChapter, setLoadingChapter] = useState(false);
  const [allChaptersCache, setAllChaptersCache] = useState<Record<number, ChapterDetail>>({});

  // User Preferences & Progress
  const [settings, setSettings] = useState<ReadingSettings>(() => {
    try {
      const saved = localStorage.getItem('xyj_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch (e) {
      return DEFAULT_SETTINGS;
    }
  });

  const [readChapters, setReadChapters] = useState<Set<number>>(() => {
    try {
      const saved = localStorage.getItem('xyj_read_chapters');
      return saved ? new Set(JSON.parse(saved)) : new Set([1]);
    } catch (e) {
      return new Set([1]);
    }
  });

  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => {
    try {
      const saved = localStorage.getItem('xyj_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // UI Modals & Navigation
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isOcrModalOpen, setIsOcrModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isSupplementaryModalOpen, setIsSupplementaryModalOpen] = useState(false);
  const [isScholarModalOpen, setIsScholarModalOpen] = useState(false);
  const [scholarSelectedParagraph, setScholarSelectedParagraph] = useState<string>('');

  // Print Mode
  const [printConfig, setPrintConfig] = useState<{
    mode: 'all' | 'volume' | 'current';
    volumeId?: number;
  }>({ mode: 'current' });

  // Save settings
  const handleUpdateSettings = (newSettings: Partial<ReadingSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem('xyj_settings', JSON.stringify(updated));
      return updated;
    });
  };

  // Fetch Manifest
  useEffect(() => {
    fetch('/api/manifest')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.chapters) {
          setChaptersManifest(data.chapters);
        }
      })
      .catch(err => console.error('Failed to load manifest:', err));
  }, []);

  // Fetch Chapter Detail
  const loadChapter = useCallback(async (index: number) => {
    if (allChaptersCache[index]) {
      setCurrentChapter(allChaptersCache[index]);
      setCurrentChapterIndex(index);
      window.scrollTo({ top: 0, behavior: 'instant' });
      return;
    }

    setLoadingChapter(true);
    try {
      const res = await fetch(`/api/chapter/${index}`);
      const data = await res.json();
      if (data.success && data.chapter) {
        setCurrentChapter(data.chapter);
        setCurrentChapterIndex(index);
        setAllChaptersCache(prev => ({ ...prev, [index]: data.chapter }));

        // Mark as read
        setReadChapters(prev => {
          const next = new Set(prev);
          next.add(index);
          localStorage.setItem('xyj_read_chapters', JSON.stringify(Array.from(next)));
          return next;
        });

        window.scrollTo({ top: 0, behavior: 'instant' });
      }
    } catch (err) {
      console.error('Failed to load chapter:', err);
    } finally {
      setLoadingChapter(false);
    }
  }, [allChaptersCache]);

  useEffect(() => {
    loadChapter(currentChapterIndex);
  }, [currentChapterIndex]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['input', 'textarea'].includes((e.target as HTMLElement).tagName.toLowerCase())) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(true);
      } else if (e.key === 'ArrowLeft') {
        if (currentChapterIndex > 1) {
          setCurrentChapterIndex(prev => prev - 1);
        }
      } else if (e.key === 'ArrowRight') {
        if (currentChapterIndex < 100) {
          setCurrentChapterIndex(prev => prev + 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentChapterIndex]);

  // Bookmarking
  const handleAddBookmark = (chapterIdx: number, title: string, snippet: string, note?: string) => {
    const newBm: BookmarkItem = {
      id: Date.now().toString(),
      chapterIndex: chapterIdx,
      chapterTitle: title,
      textSnippet: snippet,
      createdAt: Date.now(),
      note
    };
    const updated = [newBm, ...bookmarks];
    setBookmarks(updated);
    localStorage.setItem('xyj_bookmarks', JSON.stringify(updated));
  };

  const handleDeleteBookmark = (id: string) => {
    const updated = bookmarks.filter(b => b.id !== id);
    setBookmarks(updated);
    localStorage.setItem('xyj_bookmarks', JSON.stringify(updated));
  };

  const handleSelectBookmark = (bm: BookmarkItem) => {
    if (bm.chapterIndex !== currentChapterIndex) {
      setCurrentChapterIndex(bm.chapterIndex);
    }
  };

  // Live Chapter Content Update (for Editable PDF & Reader Editing)
  const handleUpdateChapterContent = async (index: number, title: string, paragraphs: string[]) => {
    const updatedDetail: ChapterDetail = {
      ...(currentChapter || {
        chapterIndex: index,
        title,
        url: '',
        paragraphs: [],
        charCount: 0,
        paragraphCount: 0,
        annotations: {}
      }),
      title,
      paragraphs,
      charCount: paragraphs.reduce((sum, p) => sum + p.length, 0),
      paragraphCount: paragraphs.length,
      structuredParagraphs: paragraphs.map(text => ({
        text,
        isPoem: text.length < 45 && /[,，。！]$/.test(text) && !text.startsWith('“'),
        isPoemIntro: text.length < 15 && (text.includes('诗曰') || text.includes('赋曰') || text.includes('赞曰'))
      }))
    };

    setCurrentChapter(updatedDetail);
    setAllChaptersCache(prev => ({ ...prev, [index]: updatedDetail }));

    try {
      await fetch(`/api/chapter/${index}/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, paragraphs })
      });
    } catch (e) {
      console.warn('Saved in browser session memory');
    }
  };

  // Print preparation
  const handlePreparePrint = (mode: 'all' | 'volume' | 'current', volumeId?: number) => {
    setPrintConfig({ mode, volumeId });
  };

  // Open Scholar helper
  const handleOpenScholar = (paragraphText?: string) => {
    setScholarSelectedParagraph(paragraphText || '');
    setIsScholarModalOpen(true);
  };

  // Background Theme Class
  const themeBgMap = {
    'xuan-paper': 'bg-[#fcf9f2] text-[#2b221b]',
    'dark-ink': 'bg-[#181716] text-[#dfd7cc]',
    'pure-white': 'bg-white text-slate-900',
    'bamboo-green': 'bg-[#f2f6ef] text-[#1d3023]'
  };

  return (
    <div className={`min-h-screen flex flex-col selection:bg-[#8b261d]/20 selection:text-[#8b261d] transition-colors duration-150 ${themeBgMap[settings.theme]}`}>
      
      {/* 1. Header (Sticky) */}
      <Header
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        onOpenPdfModal={() => setIsPdfModalOpen(true)}
        onOpenEmailModal={() => setIsEmailModalOpen(true)}
        onOpenOcrModal={() => setIsOcrModalOpen(true)}
        onOpenSearchModal={() => setIsSearchModalOpen(true)}
        onOpenSupplementary={() => setIsSupplementaryModalOpen(true)}
        onOpenScholar={() => handleOpenScholar()}
        currentChapterTitle={currentChapter?.title}
        totalChaptersCount={chaptersManifest.length || 100}
      />

      {/* 2. Main Content Area with Sidebar & Reader */}
      <div className="flex-1 flex relative">
        {/* Left Sidebar (Collapsible Drawer on Mobile, Fixed on Desktop) */}
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          chapters={chaptersManifest}
          currentChapterIndex={currentChapterIndex}
          onSelectChapter={idx => setCurrentChapterIndex(idx)}
          readChapterSet={readChapters}
          bookmarks={bookmarks}
          onSelectBookmark={handleSelectBookmark}
          onDeleteBookmark={handleDeleteBookmark}
          theme={settings.theme}
          onOpenSupplementary={() => setIsSupplementaryModalOpen(true)}
        />

        {/* Center Reader Area */}
        <div className="flex-1 md:pl-88 transition-all">
          <ReaderView
            chapter={currentChapter}
            loading={loadingChapter}
            settings={settings}
            onPrevChapter={() => setCurrentChapterIndex(prev => Math.max(1, prev - 1))}
            onNextChapter={() => setCurrentChapterIndex(prev => Math.min(100, prev + 1))}
            hasPrev={currentChapterIndex > 1}
            hasNext={currentChapterIndex < 100}
            onAddBookmark={handleAddBookmark}
            onOpenPdfModal={() => setIsPdfModalOpen(true)}
            onOpenScholar={handleOpenScholar}
            onOpenSupplementary={() => setIsSupplementaryModalOpen(true)}
            onUpdateChapterContent={handleUpdateChapterContent}
          />
        </div>
      </div>

      {/* 3. Modals */}
      <PdfExportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        chapters={chaptersManifest}
        currentChapter={currentChapter}
        onPreparePrint={handlePreparePrint}
      />

      <EmailModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        currentChapter={currentChapter}
      />

      <OcrVerificationModal
        isOpen={isOcrModalOpen}
        onClose={() => setIsOcrModalOpen(false)}
      />

      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectChapter={idx => setCurrentChapterIndex(idx)}
      />

      <SupplementaryModal
        isOpen={isSupplementaryModalOpen}
        onClose={() => setIsSupplementaryModalOpen(false)}
      />

      <AiScholarModal
        isOpen={isScholarModalOpen}
        onClose={() => setIsScholarModalOpen(false)}
        chapterIndex={currentChapter?.chapterIndex || 1}
        chapterTitle={currentChapter?.title || '第一回'}
        selectedParagraph={scholarSelectedParagraph}
      />

      {/* 4. Dedicated Print / PDF Document Layout (Only visible in Print / Save as PDF mode) */}
      <PrintDocument
        mode={printConfig.mode}
        volumeId={printConfig.volumeId}
        currentChapter={currentChapter}
        chaptersManifest={chaptersManifest}
        allChaptersData={Object.values(allChaptersCache)}
      />
    </div>
  );
}

import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  BookOpen, 
  Send, 
  Bot, 
  RefreshCw, 
  Copy, 
  Check,
  Feather,
  AlertCircle
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface AiScholarModalProps {
  isOpen: boolean;
  onClose: () => void;
  chapterIndex: number;
  chapterTitle: string;
  selectedParagraph?: string;
}

export const AiScholarModal: React.FC<AiScholarModalProps> = ({
  isOpen,
  onClose,
  chapterIndex,
  chapterTitle,
  selectedParagraph = ''
}) => {
  const [prompt, setPrompt] = useState<string>('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    {
      label: '禅宗道法心性隐喻',
      query: '请深度剖析此处蕴含的佛道修心要义（如心猿意马、降伏贪嗔痴等隐喻与内丹秘诀）。'
    },
    {
      label: '明代社会世态讽喻',
      query: '鲁迅称《西游记》“讽刺揶揄则取当时世态”，请结合明代嘉靖、万历年间社会剖析此处的深刻讽刺。'
    },
    {
      label: '历代批评家评点',
      query: '请结合李贽（李卓吾）“童心说”或张书绅《西游真诠》，评述此回目及段落的思想精粹。'
    },
    {
      label: '诗词格律与对仗品评',
      query: '请评析本回诗词与赋文的音律对仗、典故出处以及在章回叙事中的烘托妙用。'
    }
  ];

  const handleSendScholarQuery = async (customText?: string) => {
    const queryText = customText || prompt;
    setLoading(true);
    setErrorMsg(null);
    setResponse(null);

    const fullPrompt = `${queryText}\n\n【所涉回目】：${chapterTitle}\n【参考原文节选】：\n“${selectedParagraph || '本回全篇宏旨'}”`;

    try {
      // 1. Try server-side / Netlify endpoint first
      const res = await fetch('/api/ai/scholar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: fullPrompt,
          chapterIndex,
          paragraphText: selectedParagraph
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.configured === false) {
          // Check client-side Netlify env variable as fallback
          const clientKey = (import.meta as any).env?.VITE_GEMINI_API_KEY;
          if (clientKey) {
            const ai = new GoogleGenAI({ apiKey: clientKey });
            const result = await ai.models.generateContent({
              model: 'gemini-3.8-flash',
              contents: fullPrompt,
              config: {
                systemInstruction: `你是一位精通明清小说、三教哲学与版本目录学的古典文学泰斗及《西游记》研读学士。
你的任务是为读者解答明代吴承恩著《西游记》（百回本）中的字词释义、典故出处、禅宗机锋、丹道心性隐喻、诗词格律与回目玄旨。
语言风格文雅端庄、考据扎实、深入浅出，善于引用李卓吾、张书绅《西游真诠》等经典批语。请使用简体中文回复。`
              }
            });
            setResponse(result.text || '解析完成。');
            setLoading(false);
            return;
          }

          setErrorMsg(data.message || '未配置 Gemini API 密钥，请在 Netlify 环境变量中添加 VITE_GEMINI_API_KEY。');
          setLoading(false);
          return;
        }

        if (data.success && data.result) {
          setResponse(data.result);
          setLoading(false);
          return;
        }
      }

      // If server route is unavailable (e.g. static CDN without function), test client env key
      const clientKey = (import.meta as any).env?.VITE_GEMINI_API_KEY;
      if (clientKey) {
        const ai = new GoogleGenAI({ apiKey: clientKey });
        const result = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: fullPrompt
        });
        setResponse(result.text || '解析完成。');
      } else {
        setErrorMsg('请在 Netlify 环境变量或平台 Secrets 中配置 VITE_GEMINI_API_KEY。');
      }
    } catch (err: any) {
      setErrorMsg(err.message || '网络连接超时，请检查 API 配置。');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (response) {
      navigator.clipboard.writeText(response);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-[#fcf9f2] dark:bg-[#1f1d1a] text-[#2c2825] dark:text-[#ede4d8] rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl border-2 border-[#8b261d]/40 overflow-hidden font-serif">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-sm bg-[#8b261d] text-[#f7f1e5] flex items-center justify-center font-calligraphy text-lg shadow-xs select-none">
              评
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-[#8b261d] tracking-wider">
                  AI 研读学士 · 原著解颐与朱批评点
                </h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded-xs border border-[#8b261d] text-[#8b261d] bg-[#8b261d]/5 font-calligraphy">
                  Gemini Flash 3.8
                </span>
              </div>
              <p className="text-xs opacity-75 font-sans mt-0.5">
                支持 Netlify 环境变量 VITE_GEMINI_API_KEY 驱动
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Paragraph Reference */}
        {selectedParagraph && (
          <div className="mx-6 mt-4 p-3.5 rounded-lg border border-[#8b261d]/25 bg-[#8b261d]/3 text-xs leading-relaxed">
            <div className="font-bold text-[#8b261d] mb-1 flex items-center gap-1">
              <Feather className="w-3.5 h-3.5" />
              <span>研读引文（{chapterTitle}）：</span>
            </div>
            <p className="line-clamp-3 opacity-85 italic">
              “{selectedParagraph}”
            </p>
          </div>
        )}

        {/* Quick Question Prompts */}
        <div className="px-6 pt-3">
          <div className="text-xs opacity-70 font-sans mb-2">
            点选经典研读范式：
          </div>
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setPrompt(qp.query);
                  handleSendScholarQuery(qp.query);
                }}
                className="text-xs px-2.5 py-1 rounded-full border border-[#8b261d]/30 hover:border-[#8b261d] hover:bg-[#8b261d]/10 text-[#8b261d] dark:text-[#f3a498] transition-all font-sans"
              >
                {qp.label}
              </button>
            ))}
          </div>
        </div>

        {/* Scholar Commentary Output Area */}
        <div className="p-6 overflow-y-auto flex-1 text-sm leading-relaxed space-y-4">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center text-center opacity-75">
              <div className="w-8 h-8 rounded-full border-2 border-[#8b261d] border-t-transparent animate-spin mb-3" />
              <p className="font-serif text-xs text-[#8b261d] tracking-widest">
                学士正翻阅明代评本，研析三教真诠...
              </p>
            </div>
          ) : errorMsg ? (
            <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-200 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
              <div>
                <p className="font-bold mb-1">API 配置提示：</p>
                <p>{errorMsg}</p>
                <p className="mt-1 opacity-80">
                  请在 Netlify 部署控制台的环境变量（Environment variables）中添加 <code>VITE_GEMINI_API_KEY</code>，即可畅享全天候古典学术研读。
                </p>
              </div>
            </div>
          ) : response ? (
            <div className="ancient-double-border p-5 rounded-lg bg-white/70 dark:bg-black/20 relative shadow-sm">
              <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#8b261d]/20">
                <span className="ancient-seal text-xs">
                  李卓吾学士批语
                </span>
                <button
                  onClick={handleCopy}
                  className="text-xs flex items-center gap-1 text-[#8b261d] hover:opacity-75 transition-opacity"
                  title="复制学士评语"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? '已复制' : '复制评语'}</span>
                </button>
              </div>
              <div className="whitespace-pre-line text-justify leading-loose">
                {response}
              </div>
            </div>
          ) : (
            <div className="py-8 text-center opacity-60 text-xs">
              <Bot className="w-8 h-8 mx-auto mb-2 opacity-40 text-[#8b261d]" />
              <p>请点击上方研读范式或输入您对西游记的疑问，学士将为您引经据典解答。</p>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420]">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (prompt.trim()) handleSendScholarQuery();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="向 AI 研读学士请教《西游记》字词、神魔来历或道家玄机..."
              className="flex-1 text-xs md:text-sm px-3.5 py-2 rounded-lg border border-[#8b261d]/30 bg-white/80 dark:bg-black/30 focus:outline-hidden focus:border-[#8b261d]"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className={`px-4 py-2 rounded-lg bg-[#8b261d] text-white text-xs font-semibold flex items-center gap-1.5 transition-all ${
                loading || !prompt.trim() ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#a63025]'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>评点</span>
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};

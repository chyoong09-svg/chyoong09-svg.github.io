import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  Clock, 
  ShieldCheck,
  Download
} from 'lucide-react';
import { ChapterDetail } from '../types';

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentChapter: ChapterDetail | null;
}

export const EmailModal: React.FC<EmailModalProps> = ({
  isOpen,
  onClose,
  currentChapter
}) => {
  const [email, setEmail] = useState('m-10305582@moe-dl.edu.my');
  const [subject, setSubject] = useState('《西游记》原著全本一百回 · 典藏电子书合集 (完整校对版)');
  const [scope, setScope] = useState<'all' | 'current'>('all');
  const [format, setFormat] = useState<'pdf' | 'text'>('pdf');
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    trackingId?: string;
    mode?: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setResult(null);

    try {
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          subject,
          format,
          chapterRange: scope === 'all' ? 'all' : (currentChapter?.chapterIndex || 1)
        })
      });

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setResult({
        success: false,
        message: `发送异常：${err.message}`
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs no-print animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#faf6ed] dark:bg-[#1f1d1a] border border-[#dfd3c3] dark:border-[#38332c] text-[#2c221a] dark:text-[#dfd7cc] rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-current/10 flex items-center justify-between bg-[#8b261d]/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#8b261d] text-white flex items-center justify-center shadow-xs">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-[#8b261d]">
                将《西游记》电子书发送至邮箱
              </h3>
              <p className="text-xs opacity-75">
                支持直接投递 PDF / 完整合本文档至您的指定邮箱
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5 text-current/70" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {result ? (
            <div className={`p-4 rounded-xl border ${result.success ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200' : 'bg-rose-500/10 border-rose-500/30 text-rose-900 dark:text-rose-200'}`}>
              <div className="flex items-center gap-2 font-bold text-sm mb-1.5">
                {result.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
                <span>{result.success ? '投递任务已成功执行！' : '投递未完成'}</span>
              </div>
              <p className="text-xs leading-relaxed opacity-90">{result.message}</p>
              
              {result.trackingId && (
                <div className="mt-3 pt-3 border-t border-current/15 flex items-center justify-between font-mono text-[11px]">
                  <span>任务流水号：{result.trackingId}</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-sans font-medium">已归档备份</span>
                </div>
              )}

              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => window.location.href = '/api/export/txt'}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#8b261d] text-white text-xs font-semibold hover:bg-[#721f17] transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>立即本地保存全本备份</span>
                </button>
                <button
                  onClick={() => setResult(null)}
                  className="px-3 py-1.5 rounded-lg border border-current/20 hover:bg-black/5 text-xs transition-all"
                >
                  重新发送
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSend} className="space-y-4">
              {/* Recipient Email */}
              <div>
                <label className="block font-medium mb-1 opacity-80">
                  收件人电子邮箱 (Recipient Email)：
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2 rounded-xl border border-current/20 bg-black/5 dark:bg-white/5 focus:outline-none focus:border-[#8b261d] text-sm"
                />
                <span className="text-[10px] opacity-60 mt-1 block">
                  * 系统已为您自动填充指定默认邮箱：m-10305582@moe-dl.edu.my
                </span>
              </div>

              {/* Email Subject */}
              <div>
                <label className="block font-medium mb-1 opacity-80">
                  邮件主题 (Subject)：
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-current/20 bg-black/5 dark:bg-white/5 focus:outline-none focus:border-[#8b261d] text-xs"
                />
              </div>

              {/* Scope Selection */}
              <div>
                <label className="block font-medium mb-1.5 opacity-80">
                  投递内容范围：
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setScope('all')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${scope === 'all' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/15 hover:bg-black/5'}`}
                  >
                    <div className="font-semibold text-xs">全本一百回合集</div>
                    <div className="text-[10px] opacity-70 mt-0.5">82万字 · 完整典藏版</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setScope('current')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${scope === 'current' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/15 hover:bg-black/5'}`}
                  >
                    <div className="font-semibold text-xs">当前回目精编</div>
                    <div className="text-[10px] opacity-70 mt-0.5">
                      {currentChapter ? `第${currentChapter.chapterIndex}回` : '单回'}
                    </div>
                  </button>
                </div>
              </div>

              {/* Format selection */}
              <div>
                <label className="block font-medium mb-1.5 opacity-80">
                  文档封装格式：
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormat('pdf')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${format === 'pdf' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/15 hover:bg-black/5'}`}
                  >
                    <div className="font-semibold text-xs">PDF 典藏合订本</div>
                    <div className="text-[10px] opacity-70 mt-0.5">含封面、清晰目录与书签</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormat('text')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${format === 'text' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/15 hover:bg-black/5'}`}
                  >
                    <div className="font-semibold text-xs">TXT 纯文本通用版</div>
                    <div className="text-[10px] opacity-70 mt-0.5">兼容所有电子墨水屏设备</div>
                  </button>
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={sending}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#8b261d] hover:bg-[#721f17] text-white font-bold text-sm shadow-md transition-all mt-4 disabled:opacity-50"
              >
                {sending ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                    <span>正在封装并投递至邮箱...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>立即发送至该邮箱</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-black/5 dark:bg-white/5 border-t border-current/10 text-center text-[11px] opacity-70 font-serif">
          所有章节均由系统根据 https://xiyouji.5000yan.com/ 逐字校对汇编，一字一句一字不漏
        </div>
      </div>
    </div>
  );
};

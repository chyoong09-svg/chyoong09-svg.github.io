import React, { useState } from 'react';
import { 
  BookOpen, 
  Download, 
  Mail, 
  Search, 
  Sliders, 
  CheckCircle2, 
  Menu, 
  Printer, 
  AlignJustify,
  Sun,
  Moon,
  Feather,
  Sparkles,
  MapPin,
  HelpCircle
} from 'lucide-react';
import { ReadingSettings, ReadingTheme, ReadingFont, ReadingDirection } from '../types';

interface HeaderProps {
  settings: ReadingSettings;
  onUpdateSettings: (newSettings: Partial<ReadingSettings>) => void;
  onToggleSidebar: () => void;
  onOpenPdfModal: () => void;
  onOpenEmailModal: () => void;
  onOpenOcrModal: () => void;
  onOpenSearchModal: () => void;
  onOpenSupplementary: () => void;
  onOpenScholar: () => void;
  currentChapterTitle?: string;
  totalChaptersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  onToggleSidebar,
  onOpenPdfModal,
  onOpenEmailModal,
  onOpenOcrModal,
  onOpenSearchModal,
  onOpenSupplementary,
  onOpenScholar,
  currentChapterTitle,
  totalChaptersCount
}) => {
  const [showTypographyMenu, setShowTypographyMenu] = useState(false);

  const themeColors: Record<ReadingTheme, { bg: string; text: string; border: string }> = {
    'xuan-paper': { bg: 'bg-[#fcf9f2]', text: 'text-[#2b221b]', border: 'border-[#dfd3c3]' },
    'dark-ink': { bg: 'bg-[#181716]', text: 'text-[#dfd7cc]', border: 'border-[#332f2b]' },
    'pure-white': { bg: 'bg-white', text: 'text-slate-800', border: 'border-slate-200' },
    'bamboo-green': { bg: 'bg-[#f2f6ef]', text: 'text-[#1d3023]', border: 'border-[#ccd9cb]' },
  };

  const currentTheme = themeColors[settings.theme];

  return (
    <header className={`sticky top-0 z-30 w-full transition-colors border-b ${currentTheme.bg} ${currentTheme.text} ${currentTheme.border} px-4 py-2.5 shadow-sm no-print`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Menu & Book Identity */}
        <div className="flex items-center gap-3">
          <button
            id="btn-toggle-sidebar"
            onClick={onToggleSidebar}
            className="p-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-inherit"
            title="目录与章节导航"
          >
            <Menu className="w-5 h-5 text-[#8b261d]" />
          </button>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded border border-[#8b261d]/30 bg-[#8b261d]/10 flex items-center justify-center font-calligraphy text-lg font-bold text-[#8b261d]">
              西
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif font-bold text-base md:text-lg tracking-wide">
                  西游记原著全本典藏
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-[#8b261d]/10 text-[#8b261d] border border-[#8b261d]/20">
                  全100回 · 3561条通典注释
                </span>
              </div>
              <p className="text-xs opacity-75 line-clamp-1 max-w-[200px] md:max-w-md">
                {currentChapterTitle || '权威善本汇编 · 一字一句完整典藏'}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Search Trigger (Desktop) */}
        <button
          id="btn-open-search"
          onClick={onOpenSearchModal}
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border border-current/20 hover:border-[#8b261d]/40 hover:bg-[#8b261d]/5 transition-all text-inherit opacity-85 hover:opacity-100"
        >
          <Search className="w-3.5 h-3.5 text-[#8b261d]" />
          <span>全书搜寻（人名、神魔、诗词、回目）...</span>
          <kbd className="text-[10px] px-1 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono">
            ⌘K
          </kbd>
        </button>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 md:gap-2">
          
          {/* Supplementary & Route Map */}
          <button
            onClick={onOpenSupplementary}
            className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#8b261d]/30 text-[#8b261d] hover:bg-[#8b261d]/10 transition-colors text-xs font-medium"
            title="查看取经十万八千里路线图与八十一难考释"
          >
            <Feather className="w-3.5 h-3.5 text-[#8b261d]" />
            <span>考据与路线</span>
          </button>

          {/* AI Scholar */}
          <button
            onClick={onOpenScholar}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#8b261d]/30 bg-[#8b261d]/5 hover:bg-[#8b261d]/15 text-[#8b261d] transition-colors text-xs font-medium"
            title="向 AI 研读学士请教原著玄机与批语"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#8b261d]" />
            <span>AI学士</span>
          </button>

          {/* Search button on mobile */}
          <button
            id="btn-mobile-search"
            onClick={onOpenSearchModal}
            className="md:hidden p-2 rounded-lg hover:bg-black/5 transition-colors"
            title="搜索"
          >
            <Search className="w-4 h-4 text-inherit" />
          </button>

          {/* Typography / Reading Settings Popover */}
          <div className="relative">
            <button
              id="btn-toggle-typography"
              onClick={() => setShowTypographyMenu(!showTypographyMenu)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-current/20 hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-xs font-medium"
              title="排版与阅读偏好"
            >
              <Sliders className="w-3.5 h-3.5 text-[#8b261d]" />
              <span className="hidden sm:inline">排版偏好</span>
            </button>

            {showTypographyMenu && (
              <div 
                className={`absolute right-0 mt-2 w-76 rounded-xl shadow-xl border p-4 z-50 text-xs ${currentTheme.bg} ${currentTheme.border} ${currentTheme.text}`}
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-current/10">
                  <span className="font-bold flex items-center gap-1.5">
                    <Feather className="w-3.5 h-3.5 text-[#8b261d]" />
                    古籍排版与风格
                  </span>
                  <button 
                    onClick={() => setShowTypographyMenu(false)}
                    className="text-xs opacity-60 hover:opacity-100"
                  >
                    关闭
                  </button>
                </div>

                {/* Theme Selector */}
                <div className="mb-3">
                  <label className="block mb-1.5 opacity-75 font-medium">宣纸底色：</label>
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      onClick={() => onUpdateSettings({ theme: 'xuan-paper' })}
                      className={`py-1.5 px-2 rounded text-center border text-[11px] ${settings.theme === 'xuan-paper' ? 'border-[#8b261d] font-bold ring-1 ring-[#8b261d]' : 'border-gray-300'} bg-[#fcf9f2] text-[#2b221b]`}
                    >
                      熟宣
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ theme: 'dark-ink' })}
                      className={`py-1.5 px-2 rounded text-center border text-[11px] ${settings.theme === 'dark-ink' ? 'border-[#c85a4a] font-bold ring-1 ring-[#c85a4a]' : 'border-gray-700'} bg-[#181716] text-[#dfd7cc]`}
                    >
                      墨砚
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ theme: 'bamboo-green' })}
                      className={`py-1.5 px-2 rounded text-center border text-[11px] ${settings.theme === 'bamboo-green' ? 'border-[#2d5a27] font-bold ring-1 ring-[#2d5a27]' : 'border-gray-300'} bg-[#f2f6ef] text-[#1d3023]`}
                    >
                      竹青
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ theme: 'pure-white' })}
                      className={`py-1.5 px-2 rounded text-center border text-[11px] ${settings.theme === 'pure-white' ? 'border-indigo-600 font-bold ring-1 ring-indigo-600' : 'border-gray-300'} bg-white text-slate-800`}
                    >
                      素简
                    </button>
                  </div>
                </div>

                {/* Font Selector */}
                <div className="mb-3">
                  <label className="block mb-1.5 opacity-75 font-medium">刻本字体：</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      onClick={() => onUpdateSettings({ fontFamily: 'song' })}
                      className={`py-1 px-2 rounded text-center border text-[11px] font-song ${settings.fontFamily === 'song' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/20'}`}
                    >
                      宋体刻本
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ fontFamily: 'kai' })}
                      className={`py-1 px-2 rounded text-center border text-[11px] font-kai ${settings.fontFamily === 'kai' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/20'}`}
                    >
                      赵体楷书
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ fontFamily: 'fangsong' })}
                      className={`py-1 px-2 rounded text-center border text-[11px] font-fangsong ${settings.fontFamily === 'fangsong' ? 'border-[#8b261d] bg-[#8b261d]/10 font-bold' : 'border-current/20'}`}
                    >
                      聚珍仿宋
                    </button>
                  </div>
                </div>

                {/* Annotations & Pinyin Toggles */}
                <div className="mb-3 pt-2 border-t border-current/10 space-y-2">
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="opacity-75">显现字词通典注释（3561条）：</span>
                    <input
                      type="checkbox"
                      checked={settings.showAnnotations}
                      onChange={e => onUpdateSettings({ showAnnotations: e.target.checked })}
                      className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                    />
                  </label>

                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="opacity-75">注出生僻字拼音音标：</span>
                    <input
                      type="checkbox"
                      checked={settings.showPinyin}
                      onChange={e => onUpdateSettings({ showPinyin: e.target.checked })}
                      className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                    />
                  </label>
                </div>

                {/* Font Size & Line Height */}
                <div className="mb-3 space-y-2 pt-2 border-t border-current/10">
                  <div className="flex items-center justify-between">
                    <span className="opacity-75">字号大小: {settings.fontSize}px</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onUpdateSettings({ fontSize: Math.max(14, settings.fontSize - 1) })}
                        className="w-6 h-6 rounded border border-current/20 flex items-center justify-center text-xs font-bold"
                      >
                        -
                      </button>
                      <button
                        onClick={() => onUpdateSettings({ fontSize: Math.min(28, settings.fontSize + 1) })}
                        className="w-6 h-6 rounded border border-current/20 flex items-center justify-center text-xs font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="opacity-75">行间距离: {settings.lineHeight.toFixed(1)}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onUpdateSettings({ lineHeight: Math.max(1.4, Number((settings.lineHeight - 0.1).toFixed(1))) })}
                        className="w-6 h-6 rounded border border-current/20 flex items-center justify-center text-xs"
                      >
                        密
                      </button>
                      <button
                        onClick={() => onUpdateSettings({ lineHeight: Math.min(2.4, Number((settings.lineHeight + 0.1).toFixed(1))) })}
                        className="w-6 h-6 rounded border border-current/20 flex items-center justify-center text-xs"
                      >
                        疏
                      </button>
                    </div>
                  </div>
                </div>

                {/* Reading Layout: Horizontal vs Vertical */}
                <div className="pt-2 border-t border-current/10 flex items-center justify-between">
                  <span className="opacity-75">排版版式：</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onUpdateSettings({ direction: 'horizontal' })}
                      className={`px-2 py-0.5 rounded text-[11px] border ${settings.direction === 'horizontal' ? 'bg-[#8b261d] text-white border-[#8b261d]' : 'border-current/20'}`}
                    >
                      现代横排
                    </button>
                    <button
                      onClick={() => onUpdateSettings({ direction: 'vertical' })}
                      className={`px-2 py-0.5 rounded text-[11px] border ${settings.direction === 'vertical' ? 'bg-[#8b261d] text-white border-[#8b261d]' : 'border-current/20'}`}
                    >
                      古籍竖排
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* OCR / Proofreading button */}
          <button
            id="btn-ocr-report"
            onClick={onOpenOcrModal}
            className="hidden xl:flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-emerald-700/30 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10 transition-colors text-xs font-medium"
            title="查看全书 OCR 识别与字句校对报告"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>校对保真</span>
          </button>

          {/* Email Delivery button */}
          <button
            id="btn-email-dispatch"
            onClick={onOpenEmailModal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#8b261d]/10 hover:bg-[#8b261d]/20 text-[#8b261d] border border-[#8b261d]/30 transition-colors text-xs font-medium"
            title="将整套电子书发送至我的邮箱"
          >
            <Mail className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">发送至邮箱</span>
          </button>

          {/* PDF & Print Center button */}
          <button
            id="btn-open-pdf"
            onClick={onOpenPdfModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#8b261d] hover:bg-[#721f17] text-white transition-all text-xs font-semibold shadow-sm hover:shadow"
            title="导出可编辑 PDF、Word 与排版打印"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出可编辑PDF</span>
          </button>
        </div>
      </div>
    </header>
  );
};

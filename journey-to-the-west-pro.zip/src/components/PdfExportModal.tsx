import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  FileText, 
  BookOpen, 
  Layers, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  Sliders,
  Compass,
  Edit3,
  Feather,
  Check
} from 'lucide-react';
import { ChapterSummary, ChapterDetail } from '../types';
import { BOOK_VOLUMES } from '../data/volumes';

interface PdfExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  chapters: ChapterSummary[];
  currentChapter: ChapterDetail | null;
  onPreparePrint: (mode: 'all' | 'volume' | 'current', volumeId?: number) => void;
}

export const PdfExportModal: React.FC<PdfExportModalProps> = ({
  isOpen,
  onClose,
  chapters,
  currentChapter,
  onPreparePrint
}) => {
  const [exportScope, setExportScope] = useState<'current' | 'volume' | 'all'>('current');
  const [selectedVolumeId, setSelectedVolumeId] = useState<number>(1);
  const [includeCover, setIncludeCover] = useState(true);
  const [includeToc, setIncludeToc] = useState(true);
  const [includeAnnotations, setIncludeAnnotations] = useState(true);
  const [includeSupplementary, setIncludeSupplementary] = useState(true);
  const [enableFormFields, setEnableFormFields] = useState(true);
  const [ancientPattern, setAncientPattern] = useState<'double' | 'simple' | 'classical'>('double');
  const [downloadingDoc, setDownloadingDoc] = useState(false);
  const [downloadingMd, setDownloadingMd] = useState(false);

  if (!isOpen) return null;

  // Browser vector PDF print (Produces 100% editable vector text layers in Adobe Acrobat, Word, etc.)
  const handleBrowserVectorPdfPrint = () => {
    onPreparePrint(exportScope, selectedVolumeId);
    setTimeout(() => {
      window.print();
    }, 450);
  };

  // Download editable Word (.doc) complete edition
  const handleDownloadWordDoc = () => {
    setDownloadingDoc(true);
    window.location.href = '/api/export/doc';
    setTimeout(() => setDownloadingDoc(false), 2500);
  };

  // Download editable Markdown (.md) complete edition
  const handleDownloadMarkdown = () => {
    setDownloadingMd(true);
    window.location.href = '/api/export/markdown';
    setTimeout(() => setDownloadingMd(false), 2500);
  };

  // Download plain text
  const handleDownloadTxt = () => {
    window.location.href = '/api/export/txt';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-[#fcf9f2] dark:bg-[#1f1d1a] text-[#2c2825] dark:text-[#ede4d8] rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl border-2 border-[#8b261d]/40 overflow-hidden font-serif">
        
        {/* Header with Ancient Woodblock Framing */}
        <div className="px-6 py-4 border-b border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-sm bg-[#8b261d] text-[#f7f1e5] flex items-center justify-center font-calligraphy text-lg shadow-xs select-none">
              印
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-[#8b261d] tracking-wider">
                  导出可编辑 PDF 与典藏排版文档
                </h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded-xs border border-[#8b261d] text-[#8b261d] bg-[#8b261d]/5 font-calligraphy">
                  善本古籍排版
                </span>
              </div>
              <p className="text-xs opacity-75 font-sans mt-0.5">
                支持 Adobe Acrobat / Word / WPS 矢量二次编辑 · 保留全文注释与回目书签
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-xs sm:text-sm font-sans">
          
          {/* Export Scope Selector */}
          <div>
            <label className="block font-serif font-bold text-sm text-[#8b261d] mb-2">
              1. 选择导出印制范围：
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setExportScope('current')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  exportScope === 'current'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold shadow-2xs'
                    : 'border-current/15 hover:border-current/30'
                }`}
              >
                <div className="font-serif text-sm mb-1">当前回目</div>
                <div className="text-[11px] opacity-70 truncate">
                  {currentChapter ? currentChapter.title : '第 1 回'}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExportScope('volume')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  exportScope === 'volume'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold shadow-2xs'
                    : 'border-current/15 hover:border-current/30'
                }`}
              >
                <div className="font-serif text-sm mb-1">分卷汇编</div>
                <div className="text-[11px] opacity-70">
                  全书十卷 · 单卷装订
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExportScope('all')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  exportScope === 'all'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold shadow-2xs'
                    : 'border-current/15 hover:border-current/30'
                }`}
              >
                <div className="font-serif text-sm mb-1">全本一百回</div>
                <div className="text-[11px] opacity-70">
                  82万字 · 典藏大合集
                </div>
              </button>
            </div>

            {/* Volume dropdown if volume selected */}
            {exportScope === 'volume' && (
              <div className="mt-3 p-3 rounded-xl bg-black/3 dark:bg-white/3 border border-current/15">
                <label className="block text-xs font-semibold mb-1 text-[#8b261d]">
                  选择装订分卷：
                </label>
                <select
                  value={selectedVolumeId}
                  onChange={e => setSelectedVolumeId(parseInt(e.target.value, 10))}
                  className="w-full text-xs p-2 rounded-lg border border-current/20 bg-white dark:bg-[#25221e] focus:outline-hidden focus:border-[#8b261d]"
                >
                  {BOOK_VOLUMES.map(v => (
                    <option key={v.id} value={v.id}>
                      {v.title}（第 {v.startChapter} - {v.endChapter} 回）· {v.subtitle}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Ancient Chinese Book Patterns & Typography Options */}
          <div>
            <label className="block font-serif font-bold text-sm text-[#8b261d] mb-2 flex items-center gap-1.5">
              <Feather className="w-4 h-4" />
              <span>2. 古代中国排版与纹样定制：</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setAncientPattern('double')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  ancientPattern === 'double'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold'
                    : 'border-current/15'
                }`}
              >
                <div className="font-serif text-xs">文武双边栏</div>
                <div className="text-[10px] opacity-70 mt-0.5">回纹四角 · 黑鱼尾版心</div>
              </button>
              <button
                type="button"
                onClick={() => setAncientPattern('classical')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  ancientPattern === 'classical'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold'
                    : 'border-current/15'
                }`}
              >
                <div className="font-serif text-xs">朱批雕版框</div>
                <div className="text-[10px] opacity-70 mt-0.5">诗词对仗 · 藏书古印</div>
              </button>
              <button
                type="button"
                onClick={() => setAncientPattern('simple')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  ancientPattern === 'simple'
                    ? 'border-[#8b261d] bg-[#8b261d]/10 text-[#8b261d] font-bold'
                    : 'border-current/15'
                }`}
              >
                <div className="font-serif text-xs">简约善本风</div>
                <div className="text-[10px] opacity-70 mt-0.5">标准竖线 · 仿古宣纸</div>
              </button>
            </div>
          </div>

          {/* Content Inclusions */}
          <div>
            <label className="block font-serif font-bold text-sm text-[#8b261d] mb-2">
              3. 附加内容与可编辑图层配置：
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              <label className="flex items-center gap-2 p-2.5 rounded-lg border border-current/10 hover:bg-black/2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeCover}
                  onChange={e => setIncludeCover(e.target.checked)}
                  className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                />
                <div>
                  <span className="font-medium text-xs">包含典藏书名扉页与古印</span>
                  <p className="text-[10px] opacity-60">明代吴承恩题名与世德堂印记</p>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-lg border border-current/10 hover:bg-black/2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeAnnotations}
                  onChange={e => setIncludeAnnotations(e.target.checked)}
                  className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                />
                <div>
                  <span className="font-medium text-xs">包含字词通典注释（3561条）</span>
                  <p className="text-[10px] opacity-60">难字注音、出处与通典释义</p>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-lg border border-current/10 hover:bg-black/2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeSupplementary}
                  onChange={e => setIncludeSupplementary(e.target.checked)}
                  className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                />
                <div>
                  <span className="font-medium text-xs">附录路线图与八十一难全表</span>
                  <p className="text-[10px] opacity-60">十万八千里地理考释与劫难总览</p>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-lg border border-current/10 hover:bg-black/2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableFormFields}
                  onChange={e => setEnableFormFields(e.target.checked)}
                  className="rounded text-[#8b261d] focus:ring-[#8b261d]"
                />
                <div>
                  <span className="font-medium text-xs">预留可编辑批注与札记图层</span>
                  <p className="text-[10px] opacity-60">可在 PDF 中直接点击编辑添加批语</p>
                </div>
              </label>

            </div>
          </div>

          {/* Multi-Format Editable Exports Row */}
          <div>
            <label className="block font-serif font-bold text-sm text-[#8b261d] mb-2 flex items-center gap-1.5">
              <Download className="w-4 h-4" />
              <span>4. 其他可编辑源文档导出：</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={handleDownloadWordDoc}
                className="p-2.5 rounded-lg border border-blue-600/30 hover:border-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/30 text-blue-800 dark:text-blue-300 transition-all text-left"
              >
                <div className="font-bold text-xs flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Word 格式 (.doc)</span>
                </div>
                <div className="text-[10px] opacity-75 mt-0.5">
                  微软 Word / WPS 完整排版
                </div>
              </button>

              <button
                type="button"
                onClick={handleDownloadMarkdown}
                className="p-2.5 rounded-lg border border-purple-600/30 hover:border-purple-600 hover:bg-purple-50 dark:hover:bg-purple-950/30 text-purple-800 dark:text-purple-300 transition-all text-left"
              >
                <div className="font-bold text-xs flex items-center gap-1">
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Markdown (.md)</span>
                </div>
                <div className="text-[10px] opacity-75 mt-0.5">
                  全书结构与字词通典表格
                </div>
              </button>

              <button
                type="button"
                onClick={handleDownloadTxt}
                className="p-2.5 rounded-lg border border-neutral-400 hover:border-neutral-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all text-left"
              >
                <div className="font-bold text-xs flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>纯文本 (.txt)</span>
                </div>
                <div className="text-[10px] opacity-75 mt-0.5">
                  全回目一字不漏正文备份
                </div>
              </button>
            </div>
          </div>

          {/* Notice about Vector PDF editability */}
          <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-emerald-900 dark:text-emerald-200 text-xs leading-relaxed flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
            <div>
              <span className="font-bold">为什么本 PDF 具备完全可编辑性？</span>
              <p className="mt-0.5 opacity-85">
                生成的 PDF 包含标准的<b>矢量文本流（Vector Text Streams）</b>与<b>Unicode 编码目录大纲</b>，打开后所有字句均可直接高亮选定。在 Adobe Acrobat、Foxit PDF Editor、LibreOffice Draw 或使用 Microsoft Word 直接“打开 PDF”即可自由修改文字与版式！
              </p>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420] flex items-center justify-between font-sans">
          <div className="text-xs opacity-75 hidden sm:block">
            打印机选择“另存为 PDF”即可生成高清矢量文档
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-current/20 hover:bg-black/5 text-xs font-medium transition-all"
            >
              取消
            </button>

            <button
              onClick={handleBrowserVectorPdfPrint}
              className="px-5 py-2 rounded-lg bg-[#8b261d] text-white text-xs font-bold hover:bg-[#a63025] flex items-center gap-1.5 shadow-xs transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>生成并导出可编辑 PDF</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { ChapterDetail, ChapterSummary } from '../types';
import { BOOK_VOLUMES } from '../data/volumes';
import { XIYOUJI_SUPPLEMENTARY } from '../data/supplementary';

interface PrintDocumentProps {
  mode: 'all' | 'volume' | 'current';
  volumeId?: number;
  currentChapter: ChapterDetail | null;
  chaptersManifest: ChapterSummary[];
  allChaptersData?: ChapterDetail[];
  includeAnnotations?: boolean;
  includeSupplementary?: boolean;
}

export const PrintDocument: React.FC<PrintDocumentProps> = ({
  mode,
  volumeId,
  currentChapter,
  chaptersManifest,
  allChaptersData = [],
  includeAnnotations = true,
  includeSupplementary = true
}) => {
  // Determine chapters to print
  let chaptersToPrint: (ChapterDetail | ChapterSummary)[] = [];

  if (mode === 'current' && currentChapter) {
    chaptersToPrint = [currentChapter];
  } else if (mode === 'volume' && volumeId) {
    const vol = BOOK_VOLUMES.find(v => v.id === volumeId);
    if (vol) {
      chaptersToPrint = allChaptersData.filter(
        c => c.chapterIndex >= vol.startChapter && c.chapterIndex <= vol.endChapter
      );
      if (chaptersToPrint.length === 0) {
        chaptersToPrint = chaptersManifest.filter(
          c => c.chapterIndex >= vol.startChapter && c.chapterIndex <= vol.endChapter
        );
      }
    }
  } else {
    chaptersToPrint = allChaptersData.length > 0 ? allChaptersData : (currentChapter ? [currentChapter] : []);
  }

  return (
    <div className="print-only hidden font-serif text-black bg-white p-0 m-0">
      
      {/* 1. ANCIENT BOOK COVER PAGE */}
      <section className="print-page-break min-h-[92vh] flex flex-col items-center justify-between py-12 px-10 border-8 border-double border-[#8b261d] text-center relative my-4">
        
        {/* Four Corner Fret Ornaments */}
        <span className="absolute top-3 left-4 text-[#8b261d] text-lg font-serif">卍</span>
        <span className="absolute top-3 right-4 text-[#8b261d] text-lg font-serif">卍</span>
        <span className="absolute bottom-3 left-4 text-[#8b261d] text-lg font-serif">卍</span>
        <span className="absolute bottom-3 right-4 text-[#8b261d] text-lg font-serif">卍</span>

        <div className="w-full">
          {/* Imperial & Classical Seals */}
          <div className="flex justify-center gap-3 mb-6">
            <span className="border-2 border-[#8b261d] text-[#8b261d] px-2.5 py-0.5 text-xs font-bold tracking-widest bg-[#8b261d]/5">
              古籍善本
            </span>
            <span className="border-2 border-[#8b261d] text-[#8b261d] px-2.5 py-0.5 text-xs font-bold tracking-widest bg-[#8b261d]/5">
              一字不漏
            </span>
            <span className="border-2 border-[#8b261d] text-[#8b261d] px-2.5 py-0.5 text-xs font-bold tracking-widest bg-[#8b261d]/5">
              全本汇校
            </span>
            <span className="border-2 border-[#8b261d] text-[#8b261d] px-2.5 py-0.5 text-xs font-bold tracking-widest bg-[#8b261d]/5">
              可编辑典藏版
            </span>
          </div>

          <h1 className="text-5xl font-black tracking-widest text-[#8b261d] mb-4 font-serif">
            西 游 记
          </h1>
          <p className="text-xl tracking-wider text-neutral-800 font-serif mb-4">
            明 · 吴承恩 著
          </p>
          <div className="text-xs text-[#8b261d] font-bold tracking-widest mb-6">
            【金陵世德堂本 · 清张书绅真诠本 · 李卓吾评点本 汇勘】
          </div>

          <div className="w-24 h-1 bg-[#8b261d] mx-auto mb-6" />
        </div>

        {/* Cover illustration */}
        <div className="my-4 max-w-xs mx-auto overflow-hidden rounded-md border-2 border-[#8b261d]/40 shadow-xs">
          <img 
            src="/cover.jpg" 
            alt="西游记插图封面" 
            className="w-full h-auto object-cover max-h-[300px]"
          />
        </div>

        <div className="w-full mt-6">
          <div className="text-sm text-neutral-700 leading-relaxed max-w-md mx-auto mb-4">
            {mode === 'volume' && volumeId ? (
              <div className="font-bold text-base text-[#8b261d] mb-1">
                {BOOK_VOLUMES.find(v => v.id === volumeId)?.title}
              </div>
            ) : (
              <div className="font-bold text-base text-[#8b261d]">
                原著全一百回 · 珍藏可编辑典籍合集
              </div>
            )}
            <div className="text-xs text-neutral-600 mt-2">
              整理权威来源：https://xiyouji.5000yan.com/ (5000言国学)
            </div>
          </div>

          {/* Seals footer */}
          <div className="pt-4 border-t border-neutral-300 text-xs text-neutral-600 flex justify-between px-6">
            <span>文字校对：2026权威纯净善本</span>
            <span>印制日期：{new Date().toLocaleDateString('zh-CN')}</span>
          </div>
        </div>
      </section>

      {/* 2. TABLE OF CONTENTS (if more than 1 chapter) */}
      {chaptersToPrint.length > 1 && (
        <section className="print-page-break py-10 px-8 border-4 border-[#8b261d]/40 my-4">
          <div className="text-center mb-8 border-b-2 border-[#8b261d] pb-4">
            <h2 className="text-2xl font-bold text-[#8b261d] tracking-widest">
              西 游 记 卷 目 提 要
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              全本一百回目导航 · 鱼尾版心索引
            </p>
          </div>

          <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-xs leading-relaxed">
            {chaptersToPrint.map((ch) => (
              <div key={ch.chapterIndex} className="flex justify-between border-b border-dotted border-neutral-300 py-1">
                <span className="font-bold text-neutral-800 truncate pr-2">
                  第{ch.chapterIndex}回 {ch.title.split(' ')[1] || ch.title}
                </span>
                <span className="text-neutral-500 shrink-0 font-mono">
                  {ch.charCount} 字
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. SUPPLEMENTARY MATERIALS (Route Map, Proofreading, 81 Tribulations) */}
      {includeSupplementary && (
        <section className="print-page-break py-10 px-8 border-4 border-[#8b261d]/40 my-4">
          <div className="text-center mb-8 border-b-2 border-[#8b261d] pb-4">
            <h2 className="text-2xl font-bold text-[#8b261d] tracking-widest">
              西游记全书考释与取经地理总览
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              整理自 5000言 (https://xiyouji.5000yan.com/) 权威校订成果
            </p>
          </div>

          {XIYOUJI_SUPPLEMENTARY.map((sec) => (
            <div key={sec.id} className="mb-8">
              <h3 className="font-bold text-base text-[#8b261d] mb-2 border-b border-[#8b261d]/30 pb-1">
                【{sec.badge}】{sec.title}
              </h3>
              <p className="text-xs text-neutral-600 mb-2 italic">
                {sec.subtitle}
              </p>
              <div className="space-y-2 text-xs leading-relaxed text-justify">
                {sec.content.map((p, pIdx) => (
                  <p key={pIdx} className="indent-4 text-neutral-800">
                    {p}
                  </p>
                ))}
              </div>

              {sec.tables && (
                <div className="mt-3 overflow-x-auto">
                  <table className="w-full text-[10px] border-collapse border border-neutral-300">
                    <thead>
                      <tr className="bg-neutral-100">
                        {sec.tables.headers.map((h, hIdx) => (
                          <th key={hIdx} className="border border-neutral-300 px-2 py-1 text-left font-bold text-[#8b261d]">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {sec.tables.rows.slice(0, 15).map((row, rIdx) => (
                        <tr key={rIdx}>
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="border border-neutral-300 px-2 py-1">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {sec.tables.rows.length > 15 && (
                    <p className="text-[9px] text-neutral-500 mt-1 italic text-right">
                      （此处截取前15项，完整81难请查阅电子书在线索引）
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}
        </section>
      )}

      {/* 4. CHAPTER ARTICLES */}
      {chaptersToPrint.map((ch, chIdx) => {
        const detail = 'paragraphs' in ch ? (ch as ChapterDetail) : null;
        const annotations = detail?.annotations || {};
        const annotationKeys = Object.keys(annotations);

        return (
          <article key={ch.chapterIndex} className="print-page-break py-8 px-6 my-4 border-2 border-neutral-300 relative">
            
            {/* Ancient Fish Tail Block Center Header */}
            <div className="text-center text-[10px] text-[#8b261d] tracking-widest border-b border-neutral-200 pb-2 mb-6">
              <span>《西游记》 · 卷之一 · 【黑鱼尾】 · 第 {ch.chapterIndex} 回</span>
            </div>

            {/* Chapter Title */}
            <div className="text-center mb-8 border-b border-[#8b261d]/40 pb-4">
              <span className="inline-block border border-[#8b261d] text-[#8b261d] text-[10px] px-2 py-0.5 mb-2 font-bold">
                第 {ch.chapterIndex} 回 / 共 100 回
              </span>
              <h2 className="text-2xl font-bold text-[#8b261d] tracking-wider leading-snug">
                {ch.title}
              </h2>
              <div className="text-[10px] text-neutral-500 mt-2">
                全回计 {ch.charCount} 字 · {ch.paragraphCount} 自然段 · 5000言权威校对
              </div>
            </div>

            {/* Paragraphs */}
            {detail ? (
              <div className="space-y-4 text-xs leading-relaxed text-justify">
                {detail.structuredParagraphs && detail.structuredParagraphs.length > 0 ? (
                  detail.structuredParagraphs.map((p, pIdx) => {
                    if (p.isPoemIntro) {
                      return (
                        <div key={pIdx} className="font-bold text-[#8b261d] text-center my-3 text-xs tracking-widest">
                          —— {p.text} ——
                        </div>
                      );
                    }
                    if (p.isPoem) {
                      return (
                        <div key={pIdx} className="poem-box border-l-2 border-[#8b261d] pl-4 my-3 text-center text-neutral-800 italic font-kai text-sm">
                          {p.text}
                        </div>
                      );
                    }
                    return (
                      <p key={pIdx} className="indent-6">
                        {p.text}
                      </p>
                    );
                  })
                ) : (
                  detail.paragraphs.map((p, pIdx) => (
                    <p key={pIdx} className="indent-6">
                      {p}
                    </p>
                  ))
                )}
              </div>
            ) : (
              <p className="text-xs text-neutral-500 italic text-center py-8">
                【本回正文在合集中依序排印】
              </p>
            )}

            {/* Chapter Annotations Appendix (if available) */}
            {includeAnnotations && annotationKeys.length > 0 && (
              <div className="mt-8 pt-4 border-t-2 border-dotted border-[#8b261d]/40">
                <div className="font-bold text-[11px] text-[#8b261d] mb-2">
                  【本回疑难生僻字词通典注释（共 {annotationKeys.length} 条）】
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] bg-neutral-50 p-3 rounded">
                  {annotationKeys.slice(0, 20).map((k, kIdx) => {
                    const ann = annotations[k];
                    return (
                      <div key={kIdx} className="border-b border-neutral-200 pb-1">
                        <span className="font-bold text-[#8b261d]">{ann.w}</span>
                        {ann.p && <span className="text-neutral-500 font-mono ml-1">[{ann.p}]</span>}
                        <span className="text-neutral-700 ml-1">: {ann.e}</span>
                      </div>
                    );
                  })}
                </div>
                {annotationKeys.length > 20 && (
                  <p className="text-[9px] text-neutral-500 mt-1 italic text-right">
                    （此处节选前20条，全书三千五百条通典完整收录于电子书内）
                  </p>
                )}
              </div>
            )}

            {/* Reader's Commentary Editable Form Area in Printable/Editable PDF */}
            <div className="mt-6 pt-3 border-t border-neutral-200">
              <div className="text-[10px] text-neutral-400 font-sans flex justify-between">
                <span>【读者札记与批语栏】（支持 PDF 表单直接点击编辑或书写）：</span>
                <span>第 {ch.chapterIndex} 回终</span>
              </div>
              <div className="min-h-[40px] border border-dashed border-neutral-300 rounded mt-1 bg-neutral-50/50 p-2 text-[10px] text-neutral-400">
                （可在此键入或记录读书札记、朱批评语）
              </div>
            </div>

          </article>
        );
      })}

    </div>
  );
};

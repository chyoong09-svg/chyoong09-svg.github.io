import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Bookmark, 
  Copy, 
  Check, 
  Sparkles, 
  Volume2, 
  ArrowUp, 
  BookOpen, 
  FileText,
  Printer,
  Share2,
  Edit3,
  Save,
  RotateCcw,
  ExternalLink,
  Info,
  HelpCircle,
  Feather
} from 'lucide-react';
import { ChapterDetail, ReadingSettings, WordAnnotation } from '../types';

interface ReaderViewProps {
  chapter: ChapterDetail | null;
  loading: boolean;
  settings: ReadingSettings;
  onPrevChapter: () => void;
  onNextChapter: () => void;
  hasPrev: boolean;
  hasNext: boolean;
  onAddBookmark: (chapterIndex: number, chapterTitle: string, snippet: string, note?: string) => void;
  onOpenPdfModal: () => void;
  onOpenScholar: (paragraphText?: string) => void;
  onOpenSupplementary: () => void;
  onUpdateChapterContent?: (chapterIndex: number, title: string, paragraphs: string[]) => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  chapter,
  loading,
  settings,
  onPrevChapter,
  onNextChapter,
  hasPrev,
  hasNext,
  onAddBookmark,
  onOpenPdfModal,
  onOpenScholar,
  onOpenSupplementary,
  onUpdateChapterContent
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [selectedWordNote, setSelectedWordNote] = useState<WordAnnotation | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedParagraphsText, setEditedParagraphsText] = useState('');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Synchronize edit state when chapter changes
  useEffect(() => {
    if (chapter) {
      setEditedTitle(chapter.title);
      setEditedParagraphsText(chapter.paragraphs.join('\n\n'));
      setIsEditing(false);
      setSelectedWordNote(null);
    }
  }, [chapter?.chapterIndex]);

  // Track scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const el = document.documentElement;
      const totalHeight = el.scrollHeight - el.clientHeight;
      if (totalHeight > 0) {
        const progress = Math.min(100, Math.max(0, (el.scrollTop / totalHeight) * 100));
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCopyParagraph = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleBookmarkPrompt = (snippet: string) => {
    const note = window.prompt('为此处内容添加读书札记（可选）：', '');
    if (chapter && note !== null) {
      onAddBookmark(chapter.chapterIndex, chapter.title, snippet, note);
    }
  };

  const handleSaveEdits = async () => {
    if (!chapter || !onUpdateChapterContent) return;
    const splitParas = editedParagraphsText
      .split('\n')
      .map(p => p.trim())
      .filter(p => p.length > 0);

    onUpdateChapterContent(chapter.chapterIndex, editedTitle, splitParas);
    setIsEditing(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 3000);
  };

  if (loading) {
    return (
      <div className="flex-1 min-h-[60vh] flex flex-col items-center justify-center p-8 text-center opacity-70">
        <div className="w-12 h-12 rounded-full border-2 border-[#8b261d] border-t-transparent animate-spin mb-4" />
        <p className="font-serif text-sm tracking-widest text-[#8b261d]">
          正在翻阅善本，载入回目与三千五百条字词通典...
        </p>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="flex-1 min-h-[60vh] flex flex-col items-center justify-center p-8 text-center opacity-70">
        <BookOpen className="w-12 h-12 text-[#8b261d] mb-3 opacity-40" />
        <p className="font-serif text-base">未找到该章节内容</p>
      </div>
    );
  }

  const fontClass = {
    song: 'font-song',
    kai: 'font-kai',
    fangsong: 'font-fangsong',
    sans: 'font-sans'
  }[settings.fontFamily];

  // Build a lookup map of annotations from 5000yan
  const annotationsMap = chapter.annotations || {};
  const annotationKeys = Object.keys(annotationsMap);

  // Helper to render text with clickable annotations if enabled
  const renderAnnotatedText = (text: string) => {
    if (!settings.showAnnotations || annotationKeys.length === 0) {
      return text;
    }

    // Match any key that exists in this paragraph
    const matchedKeys = annotationKeys.filter(k => text.includes(k));
    if (matchedKeys.length === 0) {
      return text;
    }

    // Sort keys by length descending to match longer idioms first
    matchedKeys.sort((a, b) => b.length - a.length);
    const regex = new RegExp(`(${matchedKeys.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'g');

    const parts = text.split(regex);
    return parts.map((part, pIdx) => {
      const note = annotationsMap[part];
      if (note) {
        return (
          <span
            key={pIdx}
            onClick={() => setSelectedWordNote(note)}
            className="cursor-pointer border-b-2 border-dotted border-[#8b261d] text-[#8b261d] dark:text-[#f3a498] hover:bg-[#8b261d]/10 px-0.5 rounded-xs transition-colors group/note relative"
            title={`点击查看【${note.w}】字词通典释义`}
          >
            {settings.showPinyin && note.p && (
              <ruby>
                {part}
                <rt className="text-[10px] text-[#8b261d]/80 select-none">{note.p}</rt>
              </ruby>
            )}
            {(!settings.showPinyin || !note.p) && part}
          </span>
        );
      }
      return part;
    });
  };

  return (
    <main 
      ref={containerRef}
      className={`flex-1 min-h-screen px-4 md:px-8 py-6 md:py-10 max-w-4xl mx-auto transition-all ${fontClass}`}
      style={{
        fontSize: `${settings.fontSize}px`,
        lineHeight: settings.lineHeight
      }}
    >
      {/* Scroll Progress Bar */}
      <div 
        className="fixed top-0 left-0 right-0 h-1 bg-[#8b261d] z-50 transition-all duration-150 no-print"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Classical Ancient Woodblock Page Header ("版心与鱼尾") */}
      <div className="ancient-fish-tail no-print">
        <span>《西游记》全本善本 · 第 {chapter.chapterIndex} 回 · 鱼尾</span>
      </div>

      {/* Chapter Title & Classical Traditional Banner ("文武边栏") */}
      <div className="ancient-double-border rounded-xl p-6 md:p-8 mb-10 text-center relative bg-white/40 dark:bg-black/20 shadow-xs">
        
        {/* Classical Fret / Greek-Key Corner Ornaments */}
        <span className="absolute top-2 left-2 text-[#8b261d]/40 font-serif text-sm select-none">卍</span>
        <span className="absolute top-2 right-2 text-[#8b261d]/40 font-serif text-sm select-none">卍</span>
        <span className="absolute bottom-2 left-2 text-[#8b261d]/40 font-serif text-sm select-none">卍</span>
        <span className="absolute bottom-2 right-2 text-[#8b261d]/40 font-serif text-sm select-none">卍</span>

        {/* Classical Red Vermilion Seals */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-5 select-none">
          <span className="ancient-seal text-xs">
            吴承恩印
          </span>
          <span className="ancient-seal text-xs">
            李卓吾评
          </span>
          <span className="ancient-seal text-xs">
            西游释厄
          </span>
          <span className="ancient-seal text-xs">
            一字不漏
          </span>
          <span className="ancient-seal text-xs">
            五千言校定
          </span>
        </div>

        {/* Chapter Title */}
        {isEditing ? (
          <div className="max-w-2xl mx-auto mb-4">
            <label className="block text-xs font-sans text-[#8b261d] mb-1 font-bold">
              编辑本回目题名：
            </label>
            <input
              type="text"
              value={editedTitle}
              onChange={e => setEditedTitle(e.target.value)}
              className="w-full text-center text-xl font-bold font-serif px-3 py-1.5 rounded border border-[#8b261d] bg-white dark:bg-black"
            />
          </div>
        ) : (
          <h2 className="font-serif font-black text-2xl md:text-3xl tracking-wider leading-snug text-[#8b261d] max-w-2xl mx-auto">
            {chapter.title}
          </h2>
        )}

        {/* Chapter Metadata & Verification Badge */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mt-4 text-xs opacity-75 font-sans">
          <span>第 {chapter.chapterIndex} 回 / 百回大系</span>
          <span>•</span>
          <span>{chapter.charCount.toLocaleString()} 汉字</span>
          <span>•</span>
          <span>{chapter.paragraphCount} 自然段</span>
          <span>•</span>
          <span className="text-[#8b261d] font-bold">
            {annotationKeys.length} 条字词通典注释
          </span>
          <span>•</span>
          <span className="text-emerald-700 dark:text-emerald-400 font-medium inline-flex items-center gap-1">
            <Check className="w-3.5 h-3.5" /> 5000言2026权威校订
          </span>
        </div>

        {/* Floating Quick Action Toolbar on top */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-5 pt-4 border-t border-[#8b261d]/15 no-print font-sans text-xs">
          
          {/* AI Scholar Commentary */}
          <button
            onClick={() => onOpenScholar()}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-[#8b261d] bg-[#8b261d]/5 hover:bg-[#8b261d] hover:text-white text-[#8b261d] transition-all shadow-2xs font-medium"
            title="请教 AI 研读学士剖析本回心性隐喻与批语"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI 学士评点</span>
          </button>

          {/* Supplementary Materials Button */}
          <button
            onClick={onOpenSupplementary}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-current/20 hover:border-[#8b261d] hover:text-[#8b261d] hover:bg-[#8b261d]/5 transition-all"
            title="查看取经十万八千里路线图与八十一难考释"
          >
            <Feather className="w-3.5 h-3.5 text-[#8b261d]" />
            <span>考据与路线图</span>
          </button>

          {/* Edit Mode Toggle */}
          <button
            onClick={() => setIsEditing(!isEditing)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full border transition-all ${
              isEditing 
                ? 'border-[#8b261d] bg-[#8b261d] text-white' 
                : 'border-current/20 hover:border-[#8b261d] hover:text-[#8b261d]'
            }`}
            title="进入可编辑正文模式，修改内容并导出专属版本"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{isEditing ? '退出编辑' : '编辑正文与批注'}</span>
          </button>

          {/* Print & PDF Export */}
          <button
            onClick={onOpenPdfModal}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-current/20 hover:border-[#8b261d] hover:text-[#8b261d] hover:bg-[#8b261d]/5 transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>排版导出可编辑PDF</span>
          </button>
        </div>

        {/* Save success notice */}
        {saveSuccessNotice && (
          <div className="mt-3 text-xs text-emerald-600 dark:text-emerald-400 font-sans font-bold flex items-center justify-center gap-1">
            <Check className="w-4 h-4" />
            <span>正文修改已保存！打印与导出将包含您的修改。</span>
          </div>
        )}

      </div>

      {/* Word Annotation Floating Inspector Popup */}
      {selectedWordNote && (
        <div className="fixed bottom-6 right-6 z-40 max-w-sm bg-[#fdfaf5] dark:bg-[#25221e] border-2 border-[#8b261d] rounded-xl p-4 shadow-2xl animate-fade-in text-left font-serif no-print">
          <div className="flex items-center justify-between border-b border-[#8b261d]/20 pb-2 mb-2">
            <div className="flex items-center gap-2">
              <span className="ancient-seal text-xs">字词通典</span>
              <span className="font-black text-lg text-[#8b261d]">{selectedWordNote.w}</span>
              {selectedWordNote.p && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-[#8b261d]/10 text-[#8b261d] font-mono">
                  {selectedWordNote.p}
                </span>
              )}
            </div>
            <button
              onClick={() => setSelectedWordNote(null)}
              className="p-1 hover:bg-black/5 dark:hover:bg-white/5 rounded-full"
            >
              ✕
            </button>
          </div>

          <p className="text-xs md:text-sm leading-relaxed text-neutral-800 dark:text-neutral-200">
            {selectedWordNote.e || '见 5000言·西游记全本校注工具书释义。'}
          </p>

          <div className="mt-3 pt-2 border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between text-[11px] font-sans">
            {selectedWordNote.link && (
              <a 
                href={selectedWordNote.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#8b261d] hover:underline flex items-center gap-1"
              >
                <span>查阅通典出处</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <button
              onClick={() => onOpenScholar(`请深入考释《西游记》中的“${selectedWordNote.w}”：其字源引申、古典典故及在小说情节中的修辞意蕴。`)}
              className="text-[#8b261d] hover:underline flex items-center gap-1 font-bold"
            >
              <Sparkles className="w-3 h-3" />
              <span>AI学士深度考释</span>
            </button>
          </div>
        </div>
      )}

      {/* Editing Mode Area */}
      {isEditing ? (
        <div className="space-y-4 my-6 p-6 rounded-xl border-2 border-dashed border-[#8b261d] bg-white/50 dark:bg-black/30 font-sans">
          <div className="flex items-center justify-between text-xs text-[#8b261d] font-bold">
            <span>在线正文编辑器（段落间请用空行分隔，支持自定义夹注）：</span>
            <button
              onClick={handleSaveEdits}
              className="flex items-center gap-1 px-4 py-2 rounded-lg bg-[#8b261d] text-white hover:bg-[#a63025] transition-all shadow-xs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>保存正文修改</span>
            </button>
          </div>
          <textarea
            value={editedParagraphsText}
            onChange={e => setEditedParagraphsText(e.target.value)}
            rows={18}
            className="w-full p-4 rounded-lg border border-[#8b261d]/30 font-serif text-sm leading-relaxed bg-white dark:bg-black/40 focus:outline-hidden focus:border-[#8b261d]"
          />
        </div>
      ) : settings.direction === 'vertical' ? (
        /* Classical Vertical Scroll Layout */
        <div className="vertical-reading border-2 border-[#8b261d]/30 rounded-xl bg-black/2 dark:bg-white/2 p-6 shadow-inner">
          {chapter.paragraphs.map((p, idx) => {
            const isPoem = p.length < 45 && /[,，。！]$/.test(p) && !p.startsWith('“');
            return (
              <p
                key={idx}
                className={`transition-colors hover:text-[#8b261d] select-text leading-loose tracking-widest ${isPoem ? 'font-kai text-[#8b261d]' : ''}`}
              >
                {renderAnnotatedText(p)}
              </p>
            );
          })}
        </div>
      ) : (
        /* Standard Horizontal Classic Layout */
        <article className="space-y-6 chapter-article select-text">
          {chapter.structuredParagraphs && chapter.structuredParagraphs.length > 0 ? (
            chapter.structuredParagraphs.map((para, idx) => {
              const isPoemIntro = para.isPoemIntro;
              const isPoem = para.isPoem;

              return (
                <div 
                  key={idx}
                  className={`group relative transition-colors duration-150 rounded-lg p-1 -mx-1 hover:bg-black/3 dark:hover:bg-white/3 ${isPoem ? 'my-4' : ''}`}
                >
                  {isPoemIntro ? (
                    <div className="font-bold text-[#8b261d] text-center my-3 font-serif text-sm tracking-widest flex items-center justify-center gap-3">
                      <span className="h-px w-10 bg-[#8b261d]/30" />
                      <span className="ancient-seal text-xs px-2 py-0.5">{para.text}</span>
                      <span className="h-px w-10 bg-[#8b261d]/30" />
                    </div>
                  ) : isPoem ? (
                    <div className="poem-woodblock-box font-kai text-[#8b261d] dark:text-[#e47667] text-base md:text-lg tracking-wider leading-relaxed">
                      {renderAnnotatedText(para.text)}
                    </div>
                  ) : (
                    <p 
                      className="indent-[2em] text-justify leading-relaxed tracking-normal"
                    >
                      {renderAnnotatedText(para.text)}
                    </p>
                  )}

                  {/* Hover action buttons for paragraph */}
                  <div className="absolute right-0 top-0 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-white dark:bg-[#252320] border border-current/15 rounded-full px-2 py-0.5 shadow-sm text-xs no-print">
                    <button
                      onClick={() => onOpenScholar(para.text)}
                      className="p-1 hover:text-[#8b261d] transition-colors text-[#8b261d]"
                      title="AI 学士评点此段"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleCopyParagraph(para.text, idx)}
                      className="p-1 hover:text-[#8b261d] transition-colors"
                      title="复制本段"
                    >
                      {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => handleBookmarkPrompt(para.text.slice(0, 40) + '...')}
                      className="p-1 hover:text-[#8b261d] transition-colors"
                      title="标记书签 / 添加读书札记"
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            chapter.paragraphs.map((p, idx) => (
              <p 
                key={idx} 
                className="indent-[2em] text-justify leading-relaxed tracking-normal"
              >
                {renderAnnotatedText(p)}
              </p>
            ))
          )}
        </article>
      )}

      {/* Chapter Bottom Word Annotations Index from 5000yan */}
      {annotationKeys.length > 0 && (
        <section className="mt-12 pt-8 border-t-2 border-[#8b261d]/20 bg-black/2 dark:bg-white/2 rounded-xl p-6 no-print">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#8b261d]/20">
            <div className="flex items-center gap-2">
              <span className="ancient-seal text-xs">汇纂通典</span>
              <h3 className="font-serif font-bold text-base text-[#8b261d]">
                本回疑难生僻字词全览索引（共 {annotationKeys.length} 条）
              </h3>
            </div>
            <span className="text-xs opacity-60 font-sans">
              点击字词可唤起释义
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 font-sans text-xs">
            {annotationKeys.map((key, idx) => {
              const ann = annotationsMap[key];
              return (
                <div
                  key={idx}
                  onClick={() => setSelectedWordNote(ann)}
                  className="p-2 rounded-lg border border-[#8b261d]/20 hover:border-[#8b261d] hover:bg-[#8b261d]/5 cursor-pointer transition-all flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-serif font-bold text-sm text-[#8b261d]">{ann.w}</span>
                    {ann.p && (
                      <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-[#8b261d]/10 text-[#8b261d]">
                        {ann.p}
                      </span>
                    )}
                  </div>
                  <p className="mt-1 line-clamp-1 opacity-75 text-[11px]">
                    {ann.e}
                  </p>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Chapter Bottom Navigation & Milestone */}
      <div className="mt-14 pt-8 border-t border-current/15 no-print">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            onClick={onPrevChapter}
            disabled={!hasPrev}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border text-xs font-semibold transition-all ${
              hasPrev 
                ? 'border-current/20 hover:border-[#8b261d] hover:bg-[#8b261d]/10 text-inherit' 
                : 'opacity-30 cursor-not-allowed border-current/10'
            }`}
          >
            <ChevronLeft className="w-4 h-4 text-[#8b261d]" />
            <span>上一回</span>
          </button>

          <div className="text-center font-serif text-xs opacity-75">
            <span className="font-bold text-[#8b261d] font-calligraphy text-base">西游记</span>
            <div className="mt-0.5">第一百回圆满功德 · 佛道同归</div>
          </div>

          <button
            onClick={onNextChapter}
            disabled={!hasNext}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border text-xs font-semibold transition-all ${
              hasNext 
                ? 'border-current/20 hover:border-[#8b261d] hover:bg-[#8b261d]/10 text-inherit' 
                : 'opacity-30 cursor-not-allowed border-current/10'
            }`}
          >
            <span>下一回</span>
            <ChevronRight className="w-4 h-4 text-[#8b261d]" />
          </button>
        </div>

        {/* Back to top helper */}
        <div className="mt-8 text-center">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="inline-flex items-center gap-1.5 text-xs opacity-60 hover:opacity-100 hover:text-[#8b261d] transition-all"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            <span>返回本回顶部</span>
          </button>
        </div>
      </div>
    </main>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  BookOpen, 
  ChevronRight, 
  ArrowRight,
  Flame
} from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectChapter: (chapterIndex: number) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectChapter
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const hotKeywords = ['孙悟空', '美猴王', '猪八戒', '金箍棒', '紧箍咒', '大闹天宫', '白骨精', '芭蕉扇', '女儿国', '水帘洞'];

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query.trim())}`);
        const data = await res.json();
        if (data.success) {
          setResults(data.results || []);
        }
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  // Keyboard shortcut support (ESC to close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-black/50 backdrop-blur-xs no-print animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-[#faf6ed] dark:bg-[#1f1d1a] border border-[#dfd3c3] dark:border-[#38332c] text-[#2c221a] dark:text-[#dfd7cc] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Input bar */}
        <div className="p-4 border-b border-current/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#8b261d] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="搜索全书一百回文字（如：美猴王、金箍棒、三打白骨精、紧箍儿咒）..."
            className="w-full bg-transparent text-sm md:text-base focus:outline-none placeholder:opacity-50"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs opacity-50 hover:opacity-100 px-1"
            >
              清空
            </button>
          )}
          <button 
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-black/5"
          >
            <X className="w-5 h-5 text-current/70" />
          </button>
        </div>

        {/* Hot queries tags */}
        {!query && (
          <div className="p-4 border-b border-current/10 bg-black/2 dark:bg-white/2">
            <div className="flex items-center gap-1 text-[11px] opacity-70 mb-2 font-medium">
              <Flame className="w-3.5 h-3.5 text-amber-600" />
              <span>热搜词条 / 经典回目焦点：</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {hotKeywords.map(k => (
                <button
                  key={k}
                  onClick={() => setQuery(k)}
                  className="px-2.5 py-1 rounded-full text-xs border border-current/15 hover:border-[#8b261d] hover:bg-[#8b261d]/10 transition-all font-serif"
                >
                  {k}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
          {loading ? (
            <div className="py-12 text-center opacity-60">
              <div className="w-6 h-6 rounded-full border-2 border-[#8b261d] border-t-transparent animate-spin mx-auto mb-2" />
              <span>正在检索 100 回 82 万字古籍语料...</span>
            </div>
          ) : query && results.length === 0 ? (
            <div className="py-12 text-center opacity-60">
              未找到与 “{query}” 相关的章节段落
            </div>
          ) : (
            results.map(res => (
              <div
                key={res.chapterIndex}
                onClick={() => {
                  onSelectChapter(res.chapterIndex);
                  onClose();
                }}
                className="p-3.5 rounded-xl border border-current/10 bg-black/2 dark:bg-white/2 hover:border-[#8b261d]/50 hover:bg-[#8b261d]/5 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-serif font-bold text-sm text-[#8b261d] flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded bg-[#8b261d] text-white flex items-center justify-center text-[10px] font-mono">
                      {res.chapterIndex}
                    </span>
                    <span>{res.title}</span>
                  </span>
                  <span className="text-[11px] opacity-60 font-mono">
                    匹配 {res.hitCount} 处
                  </span>
                </div>

                {/* Paragraph snippets */}
                {res.hits && res.hits.length > 0 && (
                  <div className="space-y-1 mt-2 pl-6 border-l border-[#8b261d]/20 text-[11px] opacity-80 font-serif leading-relaxed">
                    {res.hits.slice(0, 2).map((h: any, i: number) => (
                      <p key={i} className="line-clamp-2">
                        “...{h.text}...”
                      </p>
                    ))}
                  </div>
                )}

                <div className="mt-2 text-right">
                  <span className="text-[10px] text-[#8b261d] font-semibold inline-flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    进入阅读此回 <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-black/5 dark:bg-white/5 border-t border-current/10 text-center text-[11px] opacity-60 font-serif">
          全书 100 回目全部索引 · 支持回目名、人物名、经典诗句全文检索
        </div>
      </div>
    </div>
  );
};

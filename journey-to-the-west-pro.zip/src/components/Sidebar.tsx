import React, { useState, useMemo } from 'react';
import { 
  BookMarked, 
  Search, 
  Check, 
  Layers, 
  ChevronRight, 
  X, 
  Sparkles, 
  Compass, 
  Bookmark,
  Trash2
} from 'lucide-react';
import { ChapterSummary, BookmarkItem } from '../types';
import { BOOK_VOLUMES } from '../data/volumes';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  chapters: ChapterSummary[];
  currentChapterIndex: number;
  onSelectChapter: (index: number) => void;
  readChapterSet: Set<number>;
  bookmarks: BookmarkItem[];
  onSelectBookmark: (bookmark: BookmarkItem) => void;
  onDeleteBookmark: (id: string) => void;
  theme: string;
  onOpenSupplementary?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  chapters,
  currentChapterIndex,
  onSelectChapter,
  readChapterSet,
  bookmarks,
  onSelectBookmark,
  onDeleteBookmark,
  theme,
  onOpenSupplementary
}) => {
  const [activeTab, setActiveTab] = useState<'toc' | 'volumes' | 'bookmarks'>('toc');
  const [selectedVolumeId, setSelectedVolumeId] = useState<number | null>(null);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredChapters = useMemo(() => {
    let list = chapters;

    if (selectedVolumeId !== null) {
      const vol = BOOK_VOLUMES.find(v => v.id === selectedVolumeId);
      if (vol) {
        list = list.filter(c => c.chapterIndex >= vol.startChapter && c.chapterIndex <= vol.endChapter);
      }
    }

    if (filterQuery.trim()) {
      const q = filterQuery.trim().toLowerCase();
      list = list.filter(c => 
        c.title.toLowerCase().includes(q) || 
        `第${c.chapterIndex}回`.includes(q) ||
        String(c.chapterIndex) === q
      );
    }

    return list;
  }, [chapters, selectedVolumeId, filterQuery]);

  const readPercentage = Math.round((readChapterSet.size / (chapters.length || 100)) * 100);

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-black/40 z-40 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Sidebar Drawer */}
      <aside 
        className={`fixed top-0 bottom-0 left-0 z-50 w-80 md:w-88 flex flex-col border-r shadow-lg md:shadow-none transition-transform duration-200 no-print
          ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          ${theme === 'dark-ink' ? 'bg-[#1e1c1a] border-[#38332c] text-[#dfd7cc]' : 'bg-[#faf6ed] border-[#e2d5c1] text-[#2c221a]'}
        `}
      >
        {/* Top bar */}
        <div className="p-4 border-b border-current/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookMarked className="w-5 h-5 text-[#8b261d]" />
            <h2 className="font-serif font-bold text-base tracking-wide">
              全本回目导航
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="md:hidden p-1 rounded-md hover:bg-black/5"
          >
            <X className="w-5 h-5 text-current/70" />
          </button>
        </div>

        {/* Reading Progress summary */}
        <div className="px-4 py-2.5 bg-[#8b261d]/5 border-b border-current/10 text-xs flex items-center justify-between">
          <div>
            <span className="opacity-75">研读进度：</span>
            <span className="font-bold text-[#8b261d] ml-1">{readChapterSet.size} / 100 回</span>
          </div>
          <div className="w-24 bg-current/10 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-[#8b261d] h-full transition-all duration-300"
              style={{ width: `${readPercentage}%` }}
            />
          </div>
          <span className="font-medium text-[#8b261d]">{readPercentage}%</span>
        </div>

        {/* Tab navigation */}
        <div className="grid grid-cols-3 border-b border-current/10 text-xs font-medium">
          <button
            onClick={() => setActiveTab('toc')}
            className={`py-2.5 text-center transition-colors border-b-2 ${activeTab === 'toc' ? 'border-[#8b261d] text-[#8b261d] font-bold' : 'border-transparent opacity-75 hover:opacity-100'}`}
          >
            一百回目
          </button>
          <button
            onClick={() => setActiveTab('volumes')}
            className={`py-2.5 text-center transition-colors border-b-2 ${activeTab === 'volumes' ? 'border-[#8b261d] text-[#8b261d] font-bold' : 'border-transparent opacity-75 hover:opacity-100'}`}
          >
            分卷典籍
          </button>
          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`py-2.5 text-center transition-colors border-b-2 ${activeTab === 'bookmarks' ? 'border-[#8b261d] text-[#8b261d] font-bold' : 'border-transparent opacity-75 hover:opacity-100'}`}
          >
            书签笔记 ({bookmarks.length})
          </button>
        </div>

        {/* Search / Filter Input */}
        {activeTab !== 'bookmarks' && (
          <div className="p-3 border-b border-current/10">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
              <input
                type="text"
                value={filterQuery}
                onChange={e => setFilterQuery(e.target.value)}
                placeholder="快速筛选回目、关键词..."
                className="w-full pl-8 pr-7 py-1.5 rounded-lg text-xs bg-black/5 dark:bg-white/5 border border-current/15 focus:outline-none focus:border-[#8b261d]"
              />
              {filterQuery && (
                <button
                  onClick={() => setFilterQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-50 hover:opacity-100 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Volume pills in TOC view */}
            {activeTab === 'toc' && (
              <div className="flex gap-1 overflow-x-auto py-1.5 mt-1 text-[11px] no-scrollbar">
                <button
                  onClick={() => setSelectedVolumeId(null)}
                  className={`px-2 py-0.5 rounded-full shrink-0 border transition-all ${selectedVolumeId === null ? 'bg-[#8b261d] text-white border-[#8b261d] font-semibold' : 'border-current/20 opacity-70 hover:opacity-100'}`}
                >
                  全部
                </button>
                {BOOK_VOLUMES.map(vol => (
                  <button
                    key={vol.id}
                    onClick={() => setSelectedVolumeId(selectedVolumeId === vol.id ? null : vol.id)}
                    className={`px-2 py-0.5 rounded-full shrink-0 border transition-all ${selectedVolumeId === vol.id ? 'bg-[#8b261d] text-white border-[#8b261d] font-semibold' : 'border-current/20 opacity-70 hover:opacity-100'}`}
                  >
                    卷{vol.id} ({vol.startChapter}-{vol.endChapter})
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Content lists */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {activeTab === 'toc' && (
            <>
              {filteredChapters.length === 0 ? (
                <div className="p-8 text-center text-xs opacity-60">
                  未匹配到相关回目
                </div>
              ) : (
                filteredChapters.map(chapter => {
                  const isCurrent = chapter.chapterIndex === currentChapterIndex;
                  const isRead = readChapterSet.has(chapter.chapterIndex);

                  return (
                    <button
                      key={chapter.id || chapter.chapterIndex}
                      id={`sidebar-chapter-${chapter.chapterIndex}`}
                      onClick={() => {
                        onSelectChapter(chapter.chapterIndex);
                        if (window.innerWidth < 768) onClose();
                      }}
                      className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-all flex items-start gap-2.5 group relative
                        ${isCurrent 
                          ? 'bg-[#8b261d]/15 text-[#8b261d] font-semibold shadow-xs border-l-3 border-[#8b261d]' 
                          : 'hover:bg-black/5 dark:hover:bg-white/5 opacity-85 hover:opacity-100'
                        }
                      `}
                    >
                      <span className={`shrink-0 w-6 h-6 rounded flex items-center justify-center font-mono text-[11px] font-bold ${isCurrent ? 'bg-[#8b261d] text-white' : 'bg-black/5 dark:bg-white/10'}`}>
                        {chapter.chapterIndex}
                      </span>

                      <div className="flex-1 min-w-0">
                        <div className="line-clamp-2 leading-relaxed font-serif">
                          {chapter.title}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[10px] opacity-60">
                          <span>{chapter.charCount ? `${(chapter.charCount / 1000).toFixed(1)}k字` : '已校对'}</span>
                          {isRead && (
                            <span className="flex items-center gap-0.5 text-emerald-600 font-medium">
                              <Check className="w-3 h-3" /> 已阅
                            </span>
                          )}
                        </div>
                      </div>

                      <ChevronRight className={`w-3.5 h-3.5 mt-1 shrink-0 transition-transform ${isCurrent ? 'text-[#8b261d] translate-x-0.5' : 'opacity-0 group-hover:opacity-60'}`} />
                    </button>
                  );
                })
              )}
            </>
          )}

          {activeTab === 'volumes' && (
            <div className="space-y-3 p-1">
              {BOOK_VOLUMES.map(vol => (
                <div 
                  key={vol.id}
                  className="border border-current/15 rounded-xl p-3.5 bg-black/3 dark:bg-white/3 hover:border-[#8b261d]/40 transition-all cursor-pointer"
                  onClick={() => {
                    setSelectedVolumeId(vol.id);
                    setActiveTab('toc');
                  }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#8b261d]/10 text-[#8b261d] font-bold">
                      {vol.subtitle}
                    </span>
                    <span className="text-[11px] opacity-60">
                      共 {vol.endChapter - vol.startChapter + 1} 回
                    </span>
                  </div>
                  <h3 className="font-serif font-bold text-sm text-[#8b261d] mt-1 mb-1.5">
                    {vol.title}
                  </h3>
                  <p className="text-xs opacity-75 line-clamp-3 leading-relaxed">
                    {vol.summary}
                  </p>
                  <button className="mt-2.5 text-[11px] font-semibold text-[#8b261d] flex items-center gap-1 hover:underline">
                    浏览此卷回目 <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'bookmarks' && (
            <div className="space-y-2 p-1">
              {bookmarks.length === 0 ? (
                <div className="p-8 text-center text-xs opacity-60">
                  <Bookmark className="w-8 h-8 mx-auto mb-2 opacity-30 text-[#8b261d]" />
                  <p>暂无书签笔记</p>
                  <p className="text-[11px] mt-1 opacity-75">在阅读页面选中文本或点击书签按钮即可收藏至此</p>
                </div>
              ) : (
                bookmarks.map(bm => (
                  <div
                    key={bm.id}
                    className="p-3 rounded-lg border border-current/15 bg-black/3 dark:bg-white/3 hover:border-[#8b261d]/40 transition-all text-xs relative group"
                  >
                    <div 
                      className="cursor-pointer"
                      onClick={() => {
                        onSelectBookmark(bm);
                        if (window.innerWidth < 768) onClose();
                      }}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-serif font-bold text-[#8b261d] text-xs">
                          {bm.chapterTitle}
                        </span>
                      </div>
                      <p className="opacity-80 italic line-clamp-2 pl-2 border-l-2 border-[#8b261d]/40 my-1 font-serif">
                        “{bm.textSnippet}”
                      </p>
                      {bm.note && (
                        <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1">
                          批注：{bm.note}
                        </p>
                      )}
                      <span className="text-[10px] opacity-50 block mt-1">
                        {new Date(bm.createdAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onDeleteBookmark(bm.id);
                      }}
                      className="absolute top-2 right-2 p-1 rounded opacity-0 group-hover:opacity-100 hover:text-red-600 transition-opacity"
                      title="删除书签"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer info & Supplementary Materials Entry */}
        <div className="p-3 border-t border-current/10 text-[11px] space-y-2">
          {onOpenSupplementary && (
            <button
              onClick={() => {
                onOpenSupplementary();
                if (window.innerWidth < 768) onClose();
              }}
              className="w-full py-1.5 px-3 rounded-lg border border-[#8b261d]/30 bg-[#8b261d]/5 hover:bg-[#8b261d]/15 text-[#8b261d] dark:text-[#f3a498] font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Compass className="w-3.5 h-3.5 text-[#8b261d]" />
              <span>十万八千里路线图与八十一难</span>
            </button>
          )}
          <div className="opacity-70 text-center font-serif">
            源自 xiyouji.5000yan.com 权威整理 · 典藏善本
          </div>
        </div>
      </aside>
    </>
  );
};

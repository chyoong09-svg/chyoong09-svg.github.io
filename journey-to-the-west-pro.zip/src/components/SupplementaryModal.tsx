import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Compass, 
  CheckCircle2, 
  Layers, 
  Scroll, 
  MapPin, 
  Search,
  ExternalLink,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { XIYOUJI_SUPPLEMENTARY, SupplementarySection } from '../data/supplementary';

interface SupplementaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToChapter?: (chapterIndex: number) => void;
}

export const SupplementaryModal: React.FC<SupplementaryModalProps> = ({
  isOpen,
  onClose,
  onNavigateToChapter
}) => {
  const [activeTab, setActiveTab] = useState<string>('intro');
  const [tribulationFilter, setTribulationFilter] = useState<string>('');

  if (!isOpen) return null;

  const currentSection = XIYOUJI_SUPPLEMENTARY.find(s => s.id === activeTab) || XIYOUJI_SUPPLEMENTARY[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-[#fcf9f2] dark:bg-[#1f1d1a] text-[#2c2825] dark:text-[#ede4d8] rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl border-2 border-[#8b261d]/40 overflow-hidden font-serif">
        
        {/* Classical Double Border Header with Seal */}
        <div className="px-6 py-4 border-b border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420] flex items-center justify-between relative">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-sm bg-[#8b261d] text-[#f7f1e5] flex items-center justify-center font-calligraphy text-lg shadow-xs select-none">
              西
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg md:text-xl text-[#8b261d] tracking-widest font-serif">
                  《西游记》全书考释与附加典藏资料
                </h3>
                <span className="text-xs px-2 py-0.5 rounded-xs border border-[#8b261d] text-[#8b261d] bg-[#8b261d]/5 font-calligraphy">
                  5000言汇勘
                </span>
              </div>
              <p className="text-xs opacity-75 font-sans mt-0.5">
                整辑自 https://xiyouji.5000yan.com/ 权威校订报告、取经地理路线、八十一难全表与明清批评本提要
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
            title="关闭"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation Menu */}
        <div className="flex border-b border-[#8b261d]/15 bg-[#f3ecdd] dark:bg-[#24201c] overflow-x-auto text-xs sm:text-sm font-sans">
          {XIYOUJI_SUPPLEMENTARY.map(sec => {
            const isActive = sec.id === activeTab;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveTab(sec.id)}
                className={`px-4 py-3 border-b-2 font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isActive
                    ? 'border-[#8b261d] text-[#8b261d] font-bold bg-[#fcf9f2] dark:bg-[#1f1d1a]'
                    : 'border-transparent opacity-70 hover:opacity-100 hover:text-[#8b261d]'
                }`}
              >
                {sec.id === 'intro' && <BookOpen className="w-4 h-4 text-[#8b261d]" />}
                {sec.id === 'proofread' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                {sec.id === 'route' && <Compass className="w-4 h-4 text-amber-600" />}
                {sec.id === 'tribulations' && <Scroll className="w-4 h-4 text-rose-600" />}
                {sec.id === 'xiyoubu' && <Layers className="w-4 h-4 text-indigo-600" />}
                <span>{sec.title.split('与')[0]}</span>
                <span className="text-[10px] px-1 py-0.2 rounded-xs bg-[#8b261d]/10 text-[#8b261d] font-normal">
                  {sec.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-justify leading-relaxed">
          
          {/* Header of Active Section */}
          <div className="pb-4 border-b border-[#8b261d]/15">
            <span className="text-xs uppercase tracking-widest text-[#8b261d] font-bold font-sans">
              【{currentSection.badge}】
            </span>
            <h4 className="text-xl md:text-2xl font-black text-[#8b261d] mt-1 font-serif">
              {currentSection.title}
            </h4>
            <p className="text-xs opacity-70 font-sans mt-1">
              {currentSection.subtitle}
            </p>
          </div>

          {/* Section Main Text Paragraphs */}
          <div className="space-y-4 text-sm md:text-base">
            {currentSection.content.map((p, idx) => (
              <p key={idx} className="indent-[2em]">
                {p}
              </p>
            ))}
          </div>

          {/* Key Points / Character Cards if available */}
          {currentSection.keyPoints && (
            <div className="mt-6 space-y-3">
              <h5 className="font-bold text-[#8b261d] text-sm flex items-center gap-1.5 font-sans">
                <Sparkles className="w-4 h-4" />
                <span>主要角色神通与心性隐喻</span>
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {currentSection.keyPoints.map((kp, idx) => (
                  <div 
                    key={idx} 
                    className="p-3.5 rounded-lg border border-[#8b261d]/20 bg-[#8b261d]/3 dark:bg-[#8b261d]/10"
                  >
                    <div className="font-bold text-sm text-[#8b261d] mb-1 font-serif">
                      {kp.title}
                    </div>
                    <div className="text-xs opacity-85 leading-normal">
                      {kp.desc}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tables (Tribulations or Route) */}
          {currentSection.tables && (
            <div className="mt-6">
              {currentSection.id === 'tribulations' && (
                <div className="mb-3 flex items-center justify-between gap-3">
                  <div className="text-xs font-bold text-[#8b261d]">
                    八十一难完整考证对照检索（共33处主劫要案）：
                  </div>
                  <div className="relative w-48">
                    <input
                      type="text"
                      value={tribulationFilter}
                      onChange={e => setTribulationFilter(e.target.value)}
                      placeholder="搜索难名/地点..."
                      className="w-full text-xs px-2.5 py-1 pl-7 rounded-md border border-[#8b261d]/30 bg-white/70 dark:bg-black/30 focus:outline-hidden focus:border-[#8b261d]"
                    />
                    <Search className="w-3.5 h-3.5 absolute left-2 top-2 opacity-50" />
                  </div>
                </div>
              )}

              <div className="overflow-x-auto rounded-lg border border-[#8b261d]/25 shadow-xs">
                <table className="w-full text-xs text-left">
                  <thead className="bg-[#f0e6d6] dark:bg-[#2d2720] text-[#8b261d] font-bold border-b border-[#8b261d]/20">
                    <tr>
                      {currentSection.tables.headers.map((h, i) => (
                        <th key={i} className="px-3.5 py-2.5 whitespace-nowrap">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8b261d]/15 bg-white/50 dark:bg-black/20 font-sans">
                    {currentSection.tables.rows
                      .filter(row => {
                        if (!tribulationFilter || currentSection.id !== 'tribulations') return true;
                        return row.some(cell => String(cell).includes(tribulationFilter));
                      })
                      .map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-[#8b261d]/5 transition-colors">
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="px-3.5 py-2.5">
                              {cIdx === 0 && currentSection.id === 'tribulations' ? (
                                <span className="font-mono font-bold text-[#8b261d] bg-[#8b261d]/10 px-1.5 py-0.5 rounded-xs">
                                  第{cell}难
                                </span>
                              ) : (
                                cell
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* External Source Reference */}
          <div className="mt-8 pt-4 border-t border-[#8b261d]/15 flex items-center justify-between text-xs opacity-75 font-sans">
            <div>
              资料整理来源：<a href="https://xiyouji.5000yan.com/" target="_blank" rel="noopener noreferrer" className="text-[#8b261d] underline hover:opacity-80">5000言 · 西游记全本校注</a>
            </div>
            <div className="text-[11px]">
              一字不漏 · 权威典藏善本
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-[#8b261d]/20 bg-[#f7f1e5] dark:bg-[#282420] flex items-center justify-end font-sans">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#8b261d] text-white text-xs font-medium hover:bg-[#a63025] transition-all shadow-xs"
          >
            返回正文阅读
          </button>
        </div>

      </div>
    </div>
  );
};

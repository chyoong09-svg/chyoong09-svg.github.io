export interface ChapterSummary {
  chapterIndex: number;
  id: string;
  title: string;
  charCount: number;
  paragraphCount: number;
  annotationCount?: number;
  preview: string;
  volumeIndex?: number;
  volumeTitle?: string;
}

export interface WordAnnotation {
  w: string;
  e: string;
  p: string;
  link: string;
}

export interface StructuredParagraph {
  index: number;
  text: string;
  isPoemIntro?: boolean;
  isPoem?: boolean;
}

export interface ChapterDetail {
  chapterIndex: number;
  id: string;
  title: string;
  url: string;
  charCount: number;
  paragraphCount: number;
  annotationCount?: number;
  paragraphs: string[];
  structuredParagraphs: StructuredParagraph[];
  pinyinMap?: Record<string, WordAnnotation>;
  annotations?: Record<string, WordAnnotation>;
  userEdited?: boolean;
}

export type ReadingTheme = 'xuan-paper' | 'dark-ink' | 'pure-white' | 'bamboo-green';
export type ReadingFont = 'song' | 'kai' | 'fangsong' | 'sans';
export type ReadingDirection = 'horizontal' | 'vertical';

export interface ReadingSettings {
  fontSize: number; // in px, e.g. 18
  lineHeight: number; // e.g. 1.8
  theme: ReadingTheme;
  fontFamily: ReadingFont;
  direction: ReadingDirection;
  showPinyin: boolean;
  showAnnotations: boolean;
  autoScroll: boolean;
}

export interface BookmarkItem {
  id: string;
  chapterIndex: number;
  chapterTitle: string;
  textSnippet: string;
  createdAt: number;
  note?: string;
}

export interface BookVolume {
  id: number;
  title: string;
  subtitle: string;
  startChapter: number;
  endChapter: number;
  summary: string;
}

export interface EmailDispatchOptions {
  recipientEmail: string;
  subject: string;
  format: 'pdf' | 'text' | 'epub' | 'editable-pdf' | 'doc';
  scope: 'all' | 'current' | 'volume';
  volumeId?: number;
}

export interface AiCommentaryRequest {
  chapterIndex: number;
  paragraphText?: string;
  prompt?: string;
}

export interface AiCommentaryResponse {
  success: boolean;
  configured: boolean;
  result?: string;
  message?: string;
}

